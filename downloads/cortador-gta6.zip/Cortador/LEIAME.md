# Cortador automático de lives (GTA 6)

## App + agendamento no site (instapost-ai)

1. Dois cliques em `INICIAR CORTADOR.bat`: abre a janela do app (lives, cortes, log).
2. Em **Seu site**, coloque o endereço do site, usuário e senha → **Conectar** (a senha não fica salva; o login vale 7 dias).
3. Em **Onde agendar**, marque as contas (Instagram / Facebook / YouTube), os horários do dia e ligue **Agendar sozinho**.
4. O app corta as lives sozinho. Quando você pedir pro Claude editar (legenda + card), cada corte editado
   é enviado ao Cloudinary e agendado no site no próximo horário livre de cada conta, e vai para `prontos\AGENDADOS`.

Só os cortes editados a partir de agora são agendados sozinhos; os antigos não.

Monitora vários canais da Twitch ao mesmo tempo. Quando o chat explode, ele corta o momento, transforma o corte em vídeo vertical 9:16 e coloca legenda automática.

## Instalar (uma vez)

```powershell
pip install -r requirements.txt
```

Também precisa do `ffmpeg` no PATH (você já tem).

## Usar

1. Edite o `config.json` e coloque os canais em `"canais"`:
   ```json
   { "twitch": "nome_do_canal", "layout": "blur" }
   ```
2. Rode:
   ```powershell
   python cortes.py
   ```
3. Os cortes aparecem em `cortes/AAAA-MM-DD/`. Cada `.mp4` vem com um `.json` que mostra o que o chat estava falando no momento, o que ajuda a criar o título.

Deixe o script aberto: ele espera os canais entrarem ao vivo sozinho.

## Layouts

Todos os cortes saem na vertical, 1080x1920 (9:16).

- `"auto"` (padrão): acha a câmera do streamer sozinho e monta a **câmera em cima (40%) e o gameplay embaixo (60%)**, com a legenda na divisão. Se não achar câmera nenhuma, usa o gameplay em tela cheia.
- `"facecam"`: o mesmo layout, mas você diz onde a câmera fica, em frações de 0 a 1 `[x, y, largura, altura]`. Por exemplo, `"facecam": [0.0, 0.0, 0.25, 0.30]` é o canto superior esquerdo. Use se o automático errar em algum streamer.
- `"blur"`: o jogo inteiro no meio, com o fundo desfocado.

## Ajustes principais (config.json)

| Campo | O que faz |
|---|---|
| `filtro_jogo` | Só grava quando a categoria da live é esse jogo (`Grand Theft Auto VI`). Se o streamer trocar de jogo, para sozinho. Deixe `""` para gravar qualquer jogo. |
| `segundos_antes` / `segundos_depois` | Tamanho do corte em volta do pico. O chat reage com atraso, então a maior parte fica antes do pico. |
| `minimo_msgs_na_janela` | Mínimo de mensagens em 10s para contar como pico. Aumente em canais gigantes e diminua em canais pequenos. |
| `multiplicador_pico` | Quantas vezes acima da média do chat precisa estar. Use 3 para normal e 4 a 5 para menos cortes, só os melhores. |
| `intervalo_minimo_entre_cortes_seg` | Tempo mínimo entre dois cortes do mesmo canal. |
| `palavras_hype` | Palavras que dão peso extra (kkkk, clipa...). |
| `qualidade` | `720p60` gasta menos disco e CPU que `best`. |
| `guardar_gravacao_minutos` | Apaga a gravação bruta antiga para não lotar o HD. |
| `legendas` / `modelo_whisper` | Use `small` (rápido) ou `medium` (mais preciso). |

## Como funciona

- **Gravação:** streamlink → ffmpeg em pedaços de 60s, um processo por canal, todos em paralelo.
- **Chat:** conexão anônima com o chat da Twitch (não precisa de login nem de chave).
- **Pico:** compara as mensagens dos últimos 10s com a média dos últimos 5 minutos.
- **Edição:** uma fila única usando a GPU (NVENC + Whisper na RTX), para não travar o PC.

## Limites

- Só Twitch por enquanto. Kick e YouTube ficam para uma próxima versão.
- O corte sai cerca de 1 minuto depois do momento, porque espera o pedaço de 60s fechar.
- Quanto mais canais, mais internet e disco: cerca de 1,5 GB/hora por canal em 720p60, mas o script apaga a gravação antiga.
- Só corte lives de quem autoriza (programas de clipagem) para não levar strike.
