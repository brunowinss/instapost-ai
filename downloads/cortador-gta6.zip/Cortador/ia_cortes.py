"""
IA que escolhe os melhores momentos de cada bloco da live (estilo Cut.Pro).

Usa qualquer API compatível com OpenAI (OpenRouter, DeepSeek, OpenAI, Groq...).
A chave fica só neste PC, em ia_config.json (nunca vai para o site).
"""
import json
import re
import urllib.error
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
ARQ = BASE / "ia_config.json"

PROVEDORES = {
    "openrouter": {"url": "https://openrouter.ai/api/v1", "modelo": "deepseek/deepseek-chat"},
    "deepseek": {"url": "https://api.deepseek.com", "modelo": "deepseek-chat"},
    "openai": {"url": "https://api.openai.com/v1", "modelo": "gpt-4o-mini"},
    "groq": {"url": "https://api.groq.com/openai/v1", "modelo": "llama-3.3-70b-versatile"},
}

PADRAO = {"provedor": "openrouter", "url": PROVEDORES["openrouter"]["url"], "modelo": PROVEDORES["openrouter"]["modelo"],
          "chave": "", "ativa": True, "nota_minima": 6, "max_por_bloco": 3, "bloco_min": 10}


class ErroIA(Exception):
    pass


def carregar():
    try:
        d = json.loads(ARQ.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    return {**PADRAO, **d}


def salvar(novos):
    atual = carregar()
    for k in ("provedor", "url", "modelo", "ativa", "nota_minima", "max_por_bloco", "bloco_min"):
        if k in novos and novos[k] not in (None, ""):
            atual[k] = novos[k]
    if novos.get("provedor") in PROVEDORES and not novos.get("url"):
        atual["url"] = PROVEDORES[novos["provedor"]]["url"]
    if novos.get("chave"):  # chave vazia = mantém a que já estava
        chave = novos["chave"].strip()
        if len(chave) < 20 or any(c.isspace() for c in chave):
            raise ErroIA("isso não parece uma chave de API (muito curta) - o navegador pode ter preenchido com uma senha salva")
        atual["chave"] = chave
    atual["nota_minima"] = max(0, min(10, int(atual["nota_minima"])))
    atual["max_por_bloco"] = max(1, min(8, int(atual["max_por_bloco"])))
    atual["bloco_min"] = max(3, min(30, int(atual["bloco_min"])))
    ARQ.write_text(json.dumps(atual, ensure_ascii=False, indent=2), encoding="utf-8")
    return atual


def publico():
    """O que pode aparecer no site (sem a chave)."""
    c = carregar()
    chave = c.get("chave") or ""
    return {k: v for k, v in c.items() if k != "chave"} | {
        "configurada": bool(chave), "chave_final": ("…" + chave[-4:]) if chave else ""}


def pronta():
    c = carregar()
    return bool(c.get("chave")) and c.get("ativa", True)


def chamar(mensagens, max_tokens=1500, temperatura=0.4):
    c = carregar()
    if not c.get("chave"):
        raise ErroIA("IA sem chave: configure na página Cortar live")
    corpo = json.dumps({"model": c["modelo"], "messages": mensagens, "max_tokens": max_tokens,
                        "temperature": temperatura}).encode("utf-8")
    req = urllib.request.Request(c["url"].rstrip("/") + "/chat/completions", data=corpo, method="POST", headers={
        "Content-Type": "application/json", "Authorization": f"Bearer {c['chave']}",
        "HTTP-Referer": "https://instapost.brunowins.com", "X-Title": "Cortador GTA 6"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            resp = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        txt = e.read().decode("utf-8", "replace")
        try:
            msg = json.loads(txt).get("error", {})
            msg = msg.get("message") if isinstance(msg, dict) else str(msg)
        except ValueError:
            msg = txt[:200]
        dicas = {401: "chave inválida", 402: "sem créditos na conta da IA", 404: "modelo não encontrado",
                 429: "limite de uso da IA atingido, tente mais tarde"}
        raise ErroIA(f"{dicas.get(e.code, 'erro da IA')} ({e.code}: {msg})") from None
    except urllib.error.URLError as e:
        raise ErroIA(f"sem conexão com a IA ({e.reason})") from None
    try:
        return resp["choices"][0]["message"]["content"] or ""
    except (KeyError, IndexError):
        raise ErroIA(f"resposta inesperada da IA: {str(resp)[:200]}") from None


def testar():
    txt = chamar([{"role": "user", "content": 'Responda só com o JSON {"ok": true}'}], max_tokens=20, temperatura=0)
    return "ok" in txt.lower()


def _json_da_resposta(txt):
    m = re.search(r"\{.*\}", txt, re.S)
    if not m:
        raise ErroIA("a IA não devolveu JSON")
    try:
        return json.loads(m.group(0))
    except ValueError:
        raise ErroIA("a IA devolveu um JSON quebrado") from None


def mmss(s):
    s = max(0, int(s))
    return f"{s // 60:02d}:{s % 60:02d}"


def escolher_momentos(nome, transcricao, chat, duracao_bloco, nota_minima=6, maximo=3):
    """
    transcricao: lista de (inicio_seg, fim_seg, texto) do bloco
    chat: lista de (seg_no_bloco, mensagem)
    Retorna lista de {"inicio","fim","nota","faixa","titulo","motivo"} (segundos dentro do bloco).
    """
    fala = "\n".join(f"[{mmss(a)}] {t.strip()}" for a, b, t in transcricao if t.strip())
    if len(fala) < 40:
        return []
    # chat resumido por janelas de 30 s: quantidade + exemplos
    janelas = {}
    for s, msg in chat:
        janelas.setdefault(int(s // 30), []).append(msg)
    chat_txt = "\n".join(f"[{mmss(k * 30)}] {len(v)} msgs: " + " | ".join(v[:6])[:220]
                         for k, v in sorted(janelas.items())) or "(sem chat)"

    sistema = (
        "Você é editor de cortes virais (TikTok/Shorts/Reels) de lives de GTA 6 no Brasil. "
        "Escolha os momentos que viram cortes bons: reação forte, piada, susto, raiva, polêmica, "
        "história engraçada, algo surpreendente do jogo, fala marcante. Ignore enrolação, menu, "
        "leitura de doação sem graça e conversa morna. Seja exigente com a nota. "
        "NUNCA invente: descreva só o que está na fala ou no chat.")
    usuario = (
        f"Streamer: {nome}. Bloco de {mmss(duracao_bloco)} da live.\n\n"
        f"TRANSCRIÇÃO (tempo dentro do bloco):\n{fala[:14000]}\n\n"
        f"CHAT (a cada 30 s):\n{chat_txt[:4000]}\n\n"
        f"Devolva até {maximo} cortes com nota >= {nota_minima}, do melhor para o pior. "
        "Cada corte entre 20 e 75 segundos, começando um pouco ANTES do momento (contexto) "
        "e terminando logo depois da reação.\n"
        'Responda SÓ este JSON: {"cortes": [{"inicio": "mm:ss", "fim": "mm:ss", "nota": 0-10, '
        f'"faixa": "frase curta em CAIXA ALTA começando com {nome.upper()}, máx 9 palavras, sem emoji, '
        'dizendo o que ele fez/como reagiu", "titulo": "legenda do post em CAIXA ALTA com 1-2 emojis, '
        'máx 60 caracteres, sem hashtags", "motivo": "por que é bom, curto"}]}. '
        'Se nada valer a pena, responda {"cortes": []}.')
    dados = _json_da_resposta(chamar([{"role": "system", "content": sistema}, {"role": "user", "content": usuario}]))

    def seg(v):
        if isinstance(v, (int, float)):
            return float(v)
        m = re.match(r"^\s*(\d+):(\d{1,2})(?::(\d{1,2}))?\s*$", str(v))
        if not m:
            return None
        a, b, c = m.groups()
        return int(a) * 3600 + int(b) * 60 + int(c) if c else int(a) * 60 + int(b)

    saida = []
    for c in dados.get("cortes", [])[:maximo]:
        ini, fim = seg(c.get("inicio")), seg(c.get("fim"))
        try:
            nota = float(c.get("nota", 0))
        except (TypeError, ValueError):
            nota = 0
        if ini is None or fim is None or nota < nota_minima:
            continue
        ini = max(0.0, ini)
        fim = min(float(duracao_bloco), fim)
        if fim - ini < 12:
            fim = min(float(duracao_bloco), ini + 30)
        if fim - ini > 90:
            fim = ini + 90
        if fim - ini < 12:
            continue
        saida.append({"inicio": ini, "fim": fim, "nota": nota,
                      "faixa": str(c.get("faixa") or "").strip(), "titulo": str(c.get("titulo") or "").strip(),
                      "motivo": str(c.get("motivo") or "").strip()})
    return saida
