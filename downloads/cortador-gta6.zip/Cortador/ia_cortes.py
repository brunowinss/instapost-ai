"""
IA que escolhe os melhores momentos de cada bloco da live (estilo Cut.Pro).

Usa qualquer API compatível com OpenAI (OpenRouter, DeepSeek, OpenAI, Groq...).
A chave fica só neste PC, em ia_config.json (nunca vai para o site).
"""
import json
import re
import urllib.error
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
ARQ = BASE / "ia_config.json"

PROVEDORES = {
    "openrouter": {"url": "https://openrouter.ai/api/v1", "modelo": "deepseek/deepseek-chat"},
    "deepseek": {"url": "https://api.deepseek.com", "modelo": "deepseek-chat"},
    "openai": {"url": "https://api.openai.com/v1", "modelo": "gpt-4o-mini"},
    "groq": {"url": "https://api.groq.com/openai/v1", "modelo": "llama-3.3-70b-versatile"},
}

PADRAO = {"provedor": "openrouter", "url": PROVEDORES["openrouter"]["url"], "modelo": PROVEDORES["openrouter"]["modelo"],
          "chave": "", "ativa": True, "nota_minima": 6, "max_por_bloco": 3, "bloco_min": 10}


class ErroIA(Exception):
    pass


# chaves que já estão no Hermes Agent (lidas na hora, nunca copiadas para cá)
HERMES_ENV = Path.home() / "AppData" / "Local" / "hermes" / ".env"
HERMES_VARS = {"openrouter": "OPENROUTER_API_KEY", "deepseek": "DEEPSEEK_API_KEY",
               "openai": "OPENAI_API_KEY", "groq": "GROQ_API_KEY"}


def chave_hermes(provedor):
    var = HERMES_VARS.get(provedor)
    try:
        for linha in HERMES_ENV.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^\s*([A-Z0-9_]+)\s*=\s*[\"']?([^\"'#\s]+)", linha)
            if m and m.group(1) == var:
                return m.group(2)
    except OSError:
        pass
    return ""


def carregar():
    try:
        d = json.loads(ARQ.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    c = {**PADRAO, **d}
    c["da_hermes"] = False
    if not c.get("chave"):
        k = chave_hermes(c["provedor"])
        if k:
            c["chave"], c["da_hermes"] = k, True
    return c


def salvar(novos):
    atual = carregar()
    if atual.pop("da_hermes", False):
        atual["chave"] = ""
    for k in ("provedor", "url", "modelo", "ativa", "nota_minima", "max_por_bloco", "bloco_min"):
        if k in novos and novos[k] not in (None, ""):
            atual[k] = novos[k]
    if novos.get("provedor") in PROVEDORES and not novos.get("url"):
        atual["url"] = PROVEDORES[novos["provedor"]]["url"]
    if novos.get("chave"):  # chave vazia = mantém a que já estava
        chave = novos["chave"].strip()
        if len(chave) < 20 or any(c.isspace() for c in chave):
            raise ErroIA("isso não parece uma chave de API (muito curta) - o navegador pode ter preenchido com uma senha salva")
        atual["chave"] = chave
    atual["nota_minima"] = max(0, min(10, int(atual["nota_minima"])))
    atual["max_por_bloco"] = max(1, min(8, int(atual["max_por_bloco"])))
    atual["bloco_min"] = max(3, min(30, int(atual["bloco_min"])))
    ARQ.write_text(json.dumps(atual, ensure_ascii=False, indent=2), encoding="utf-8")
    return atual


def publico():
    """O que pode aparecer no site (sem a chave)."""
    c = carregar()
    chave = c.get("chave") or ""
    return {k: v for k, v in c.items() if k != "chave"} | {
        "configurada": bool(chave), "chave_final": ("do Hermes " if c.get("da_hermes") else "") + (("…" + chave[-4:]) if chave else "")}


def pronta():
    c = carregar()
    return bool(c.get("chave")) and c.get("ativa", True)


def chamar(mensagens, max_tokens=1500, temperatura=0.4):
    c = carregar()
    if not c.get("chave"):
        raise ErroIA("IA sem chave: configure na página Cortar live")
    corpo = json.dumps({"model": c["modelo"], "messages": mensagens, "max_tokens": max_tokens,
                        "temperature": temperatura}).encode("utf-8")
    req = urllib.request.Request(c["url"].rstrip("/") + "/chat/completions", data=corpo, method="POST", headers={
        "Content-Type": "application/json", "Authorization": f"Bearer {c['chave']}",
        "HTTP-Referer": "https://instapost.brunowins.com", "X-Title": "Cortador GTA 6"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            resp = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        txt = e.read().decode("utf-8", "replace")
        try:
            msg = json.loads(txt).get("error", {})
            msg = msg.get("message") if isinstance(msg, dict) else str(msg)
        except ValueError:
            msg = txt[:200]
        dicas = {401: "chave inválida", 402: "sem créditos na conta da IA", 404: "modelo não encontrado",
                 429: "limite de uso da IA atingido, tente mais tarde"}
        raise ErroIA(f"{dicas.get(e.code, 'erro da IA')} ({e.code}: {msg})") from None
    except urllib.error.URLError as e:
        raise ErroIA(f"sem conexão com a IA ({e.reason})") from None
    try:
        return resp["choices"][0]["message"]["content"] or ""
    except (KeyError, IndexError):
        raise ErroIA(f"resposta inesperada da IA: {str(resp)[:200]}") from None


def testar():
    txt = chamar([{"role": "user", "content": 'Responda só com o JSON {"ok": true}'}], max_tokens=20, temperatura=0)
    return "ok" in txt.lower()


def _json_da_resposta(txt):
    m = re.search(r"\{.*\}", txt, re.S)
    if not m:
        raise ErroIA("a IA não devolveu JSON")
    try:
        return json.loads(m.group(0))
    except ValueError:
        raise ErroIA("a IA devolveu um JSON quebrado") from None


def mmss(s):
    s = max(0, int(s))
    return f"{s // 60:02d}:{s % 60:02d}"


_EN = set("the you and to is it that what are this i'm don't we your have was for be not with my he she they me just can know get go it's do what's no yeah oh okay right come let's gonna want here there got all at of in on look being you're going stop i've i'll he's she's can't won't give take make tell think need him her them our us from about like now how why where when who will would could should been were did does has had very really back up out down off fuck shit man hey".split())
_PT = set("o a que de não é eu você mano tá pra para com um uma isso aqui se no na meu vai cara do da mas então porque ele ela foi tem já vamos olha caralho porra né".split())


def fala_do_jogo(texto):
    """True se a frase é em inglês (diálogo/cutscene do GTA), não a fala do streamer brasileiro."""
    ps = re.findall(r"[a-zà-ÿ']+", (texto or "").lower())
    if len(ps) < 2:
        return False
    en = sum(p in _EN for p in ps)
    pt = sum(p in _PT for p in ps) + 2 * sum(any(c in p for c in "ãõçáéíóúâêô") for p in ps)
    return (en >= 2 and en > pt) or (en >= 1 and pt == 0 and len(ps) >= 4)


def escolher_momentos(nome, transcricao, chat, duracao_bloco, nota_minima=6, maximo=3):
    """
    Escolhe os cortes do jeito do Cut.Pro: começa no GANCHO, termina logo depois da reação,
    curto (20-45 s), e com nota por critérios (gancho, emoção, entende sozinho, final).

    transcricao: lista de (inicio_seg, fim_seg, texto) do bloco
    chat: lista de (seg_no_bloco, mensagem)
    Retorna lista de {"inicio","fim","nota","faixa","titulo","motivo"} (segundos dentro do bloco).
    """
    frases = [(a, b, t.strip()) for a, b, t in transcricao if t.strip()]
    if sum(len(t) for _, _, t in frases) < 40:
        return []
    # cada frase com número: a IA escolhe "da frase X até a frase Y" (início/fim exatos, sem cortar no meio)
    fala = "\n".join(f"#{i} [{mmss(a)}-{mmss(b)}] {t}" for i, (a, b, t) in enumerate(frases))
    janelas = {}
    for s, msg in chat:
        janelas.setdefault(int(s // 30), []).append(msg)
    media = (sum(len(v) for v in janelas.values()) / max(1, duracao_bloco / 30)) if janelas else 0
    chat_txt = "\n".join(f"[{mmss(k * 30)}] {len(v)} msgs{' (ACIMA DO NORMAL)' if len(v) > media * 1.8 and len(v) >= 5 else ''}: "
                         + " | ".join(v[:6])[:220] for k, v in sorted(janelas.items())) or "(sem chat)"

    sistema = (
        "Você é o melhor editor de cortes virais (TikTok/Shorts/Reels) de lives de GTA 6 no Brasil, "
        "no estilo das ferramentas de clipes automáticos tipo Cut.Pro/Opus Clip. "
        "Um corte bom: (1) PRENDE nos 2 primeiros segundos — começa direto na frase de impacto, pergunta, "
        "susto, grito, piada ou situação absurda, SEM introdução; (2) tem emoção/reação forte (risada, raiva, "
        "choque, surpresa, zoeira); (3) dá pra entender sem ter visto a live; (4) termina no pico — logo depois "
        "da reação/punchline, sem rabo nem conversa morna depois. "
        "Ignore: menu, loading, leitura de doação sem graça, papo de bastidor, silêncio, explicação longa. "
        "Seja exigente: a maioria dos trechos NÃO vira corte. NUNCA invente nada que não esteja na fala ou no chat. "
        "MUITO IMPORTANTE: frases marcadas [JOGO] são falas dos PERSONAGENS do GTA (cutscene/NPC, em inglês), "
        "NÃO do streamer. Elas servem só de contexto. O corte tem que ter a REAÇÃO ou a fala do PRÓPRIO streamer "
        "(frases sem [JOGO]); trecho só com diálogo do jogo NÃO vira corte. Na faixa e no título, nunca diga que o "
        "streamer falou algo que foi um personagem do jogo que falou.")
    usuario = (
        f"Streamer: {nome}. Bloco de {mmss(duracao_bloco)} da live.\n\n"
        f"TRANSCRIÇÃO (cada frase numerada, com tempo dentro do bloco):\n{fala[:15000]}\n\n"
        f"CHAT a cada 30 s (picos de chat costumam indicar o momento bom):\n{chat_txt[:4000]}\n\n"
        f"Escolha até {maximo} cortes, do melhor para o pior, sem sobrepor um ao outro.\n"
        "Para cada corte dê a nota de 0 a 10 somando: gancho (0-3) + emoção/reação (0-3) + "
        "entende sozinho (0-2) + final forte (0-2).\n"
        f"Só devolva cortes com nota >= {nota_minima}.\n"
        "Duração ideal 20 a 45 s (máx 60). 'frase_inicio' = número da frase que É o gancho (ou a frase "
        "imediatamente antes, se precisar de 1 frase de contexto). 'frase_fim' = número da frase onde a "
        "reação/punchline termina.\n"
        'Responda SÓ este JSON: {"cortes": [{"frase_inicio": 0, "frase_fim": 0, '
        '"gancho": 0, "emocao": 0, "entende": 0, "final": 0, "nota": 0, '
        f'"faixa": "frase curta em CAIXA ALTA começando com {nome.upper()}, máx 9 palavras, sem emoji, '
        'dizendo o que ele fez/como reagiu", "titulo": "legenda do post em CAIXA ALTA com 1-2 emojis, '
        'máx 60 caracteres, sem hashtags", "motivo": "por que é bom, curto"}]}. '
        'Se nada valer a pena, responda {"cortes": []}.')
    dados = _json_da_resposta(chamar([{"role": "system", "content": sistema}, {"role": "user", "content": usuario}],
                                     max_tokens=1800, temperatura=0.3))

    def num(v, padrao=None):
        try:
            return float(v)
        except (TypeError, ValueError):
            return padrao

    def idx(v):
        n = num(str(v).lstrip("#") if v is not None else None)
        return int(n) if n is not None and 0 <= n < len(frases) else None

    saida = []
    for c in dados.get("cortes", [])[: maximo * 2]:
        a, b = idx(c.get("frase_inicio")), idx(c.get("frase_fim"))
        if a is None or b is None:
            continue
        if b < a:
            a, b = b, a
        nota = num(c.get("nota"))
        partes = [num(c.get(k), 0) for k in ("gancho", "emocao", "entende", "final")]
        if nota is None or (sum(partes) and abs(sum(partes) - nota) > 1):
            nota = sum(partes)
        if nota < nota_minima:
            continue
        ini = max(0.0, frases[a][0] - 0.25)                       # começa no gancho (sem cortar a 1ª palavra)
        fim = min(float(duracao_bloco), frases[b][1] + 0.8)        # termina logo depois da reação
        # curto demais: estica até completar ~20 s com as frases seguintes
        while fim - ini < 18 and b + 1 < len(frases) and frases[b + 1][1] - ini <= 45:
            b += 1
            fim = min(float(duracao_bloco), frases[b][1] + 0.8)
        # longo demais: corta na última frase que cabe em 60 s
        while fim - ini > 60 and b > a:
            b -= 1
            fim = frases[b][1] + 0.8
        if fim - ini < 10 or fim - ini > 65:
            continue
        if any(ini < s["fim"] and fim > s["inicio"] for s in saida):  # não repete o mesmo trecho
            continue
        saida.append({"inicio": ini, "fim": fim, "nota": round(nota, 1),
                      "faixa": str(c.get("faixa") or "").strip(), "titulo": str(c.get("titulo") or "").strip(),
                      "motivo": str(c.get("motivo") or "").strip()})
        if len(saida) >= maximo:
            break
    return saida
