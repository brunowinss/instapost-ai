@echo off
chcp 65001 >nul
title Instalar Cortador
cd /d "%~dp0"
echo ============================================
echo   INSTALANDO O CORTADOR (so na primeira vez)
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo Python nao encontrado. Instalando pelo winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo.
  echo Feche esta janela e rode o INSTALAR.bat de novo.
  pause
  exit /b
)

where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo ffmpeg nao encontrado. Instalando pelo winget...
  winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements
)

echo Instalando as bibliotecas do Python...
python -m pip install --upgrade -r requirements.txt
echo.
echo ============================================
echo   PRONTO! Agora abra o INICIAR CORTADOR.bat
echo ============================================
pause
