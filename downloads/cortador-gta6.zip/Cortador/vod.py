"""
Clipar live passada (VOD): Twitch, Kick e YouTube.

Baixa o vídeo (720p), corta em pedaços de 1 min (igual à gravação ao vivo) e manda blocos de
X minutos para a MESMA fila da IA que analisa as lives ao vivo. No fim apaga o vídeo baixado.
"""
import csv
import hashlib
import json
import re
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
JOBS = {}          # id -> estado (o site mostra isso)
_LOCK = threading.Lock()


def _id(url, ini, fim):
    return hashlib.md5(f"{url.strip().lower()}|{ini}|{fim}".encode()).hexdigest()[:10]


def plataforma(url):
    u = (url or "").lower()
    return "kick" if "kick.com" in u else "twitch" if "twitch.tv" in u else "youtube" if ("youtu" in u) else "outra"


def tempo(txt):
    """'1:20:00', '80:00', '4800' ou '1h20m' -> segundos (ou None)."""
    t = str(txt or "").strip().lower()
    if not t:
        return None
    m = re.fullmatch(r"(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s?)?", t)
    if m and any(m.groups()):
        h, mi, s = (int(x or 0) for x in m.groups())
        return h * 3600 + mi * 60 + s
    partes = t.split(":")
    if all(p.isdigit() for p in partes) and len(partes) <= 3:
        n = 0
        for p in partes:
            n = n * 60 + int(p)
        return n
    raise ValueError(f"não entendi o tempo '{txt}' (use 1:20:00)")


def hms(s):
    s = int(s)
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}"


def info(url):
    """Título, canal e duração do vídeo (sem baixar)."""
    r = subprocess.run([sys.executable, "-m", "yt_dlp", "-J", "--no-warnings", "--no-playlist", url],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
    txt = r.stdout or ""
    if r.returncode != 0 or "{" not in txt:
        erro = (r.stderr or "").strip().splitlines()[-1:] or ["não consegui abrir o link"]
        raise RuntimeError(erro[0].replace("ERROR: ", "")[:200])
    d = json.loads(txt[txt.index("{"):])
    return {"titulo": d.get("title") or "", "canal": d.get("uploader") or d.get("channel") or "",
            "canal_id": (d.get("uploader_id") or d.get("channel_id") or "").lower(),
            "duracao": float(d.get("duration") or 0), "data": d.get("upload_date") or "",
            "plataforma": plataforma(url)}


def lista():
    with _LOCK:
        return [{k: v for k, v in j.items() if not k.startswith("_")}
                for j in sorted(JOBS.values(), key=lambda j: j["criado"], reverse=True)][:10]


def _set(vid, **campos):
    with _LOCK:
        if vid in JOBS:
            JOBS[vid].update(campos)


def cancelado(vid):
    with _LOCK:
        j = JOBS.get(vid)
        return bool(j and j.get("cancelar"))


def cancelar(vid):
    with _LOCK:
        j = JOBS.get(vid)
        if not j:
            return False
        j["cancelar"] = True
        if j["etapa"] not in ("pronto", "erro", "cancelado"):
            j["status"] = "cancelando…"
        proc = j.get("_proc")
    if proc and proc.poll() is None:
        try:
            proc.kill()
        except OSError:
            pass
    return True


def bloco_feito(vid, clips, erro=None):
    """Chamado pelo editor quando termina de analisar um bloco da live passada."""
    apagar = None
    with _LOCK:
        j = JOBS.get(vid)
        if not j:
            return
        j["blocos_feitos"] += 1
        j["clips"] += int(clips or 0)
        if erro:
            j["erros"].append(str(erro)[:120])
        if j["blocos_feitos"] >= j["blocos"]:
            j["etapa"] = "cancelado" if j.get("cancelar") else "pronto"
            j["status"] = ("cancelado" if j.get("cancelar") else
                           f"pronto: {j['clips']} corte(s) em Clipados" + (" (alguns blocos deram erro)" if j["erros"] else ""))
            j["fim"] = datetime.now().isoformat(timespec="seconds")
            apagar = j.get("_pasta")
        else:
            j["status"] = f"IA analisando: bloco {j['blocos_feitos'] + 1} de {j['blocos']} ({j['clips']} cortes até agora)"
    if apagar:
        shutil.rmtree(apagar, ignore_errors=True)  # o vídeo baixado não é mais necessário


class Job(threading.Thread):
    def __init__(self, editor, cfg, url, ini=None, fim=None, nome=None):
        super().__init__(daemon=True)
        self.editor, self.cfg, self.url = editor, cfg, url.strip()
        self.ini, self.fim, self.nome = ini, fim, (nome or "").strip()
        self.vid = _id(self.url, ini, fim)
        with _LOCK:
            JOBS[self.vid] = {"id": self.vid, "url": self.url, "titulo": "", "canal": self.nome,
                              "plataforma": plataforma(self.url), "etapa": "info", "status": "lendo o link…",
                              "pct": 0, "blocos": 0, "blocos_feitos": 0, "clips": 0, "erros": [],
                              "criado": datetime.now().isoformat(timespec="seconds"), "fim": "",
                              "trecho": f"{hms(ini or 0)} → {hms(fim)}" if (ini or fim) else "live inteira",
                              "cancelar": False}

    # ------------------------------------------------------------------
    def run(self):
        try:
            self._rodar()
        except Exception as e:
            _set(self.vid, etapa="erro", status=f"erro: {e}", fim=datetime.now().isoformat(timespec="seconds"))
            self._log(f"erro: {e}")
            pasta = JOBS.get(self.vid, {}).get("_pasta")
            if pasta:
                shutil.rmtree(pasta, ignore_errors=True)

    def _log(self, msg):
        try:
            import cortes
            cortes.log(JOBS[self.vid].get("canal") or "live passada", f"LIVE PASSADA: {msg}")
        except Exception:
            pass

    def _rodar(self):
        import cortes
        import ia_cortes
        if not ia_cortes.pronta():
            raise RuntimeError("a IA dos cortes não está configurada (chave no card 'IA dos cortes')")
        d = info(self.url)
        canal_cfg = None
        for c in self.cfg.get("canais", []):
            if cortes.chave_canal(c).replace("yt_", "") == d["canal_id"].lstrip("@") or \
                    (c.get("nome") or "").lower() == d["canal"].lower():
                canal_cfg = c
                break
        nome_bonito = self.nome or (canal_cfg or {}).get("nome") or d["canal"] or "Live passada"
        chave = cortes.chave_canal(canal_cfg) if canal_cfg else re.sub(r"[^a-z0-9_]", "", (d["canal_id"] or nome_bonito).lower()) or "vod"
        total = d["duracao"]
        ini = self.ini or 0
        fim = min(self.fim, total) if (self.fim and total) else total
        if total and ini >= total:
            raise RuntimeError(f"o início ({hms(ini)}) passa do fim do vídeo ({hms(total)})")
        _set(self.vid, titulo=d["titulo"], canal=nome_bonito, etapa="baixando", status="baixando o vídeo…")
        self._log(f"{nome_bonito}: '{d['titulo']}' ({hms(total)}) — baixando {hms(ini)} → {hms(fim)}")

        pasta = BASE / self.cfg["pasta_gravacao"] / chave / f"vod_{self.vid}"
        shutil.rmtree(pasta, ignore_errors=True)
        pasta.mkdir(parents=True, exist_ok=True)
        _set(self.vid, _pasta=pasta)
        arq = self._baixar(pasta, ini if self.ini else None, fim if (self.fim or self.ini) else None,
                           esperado=(fim - ini) if (self.fim or self.ini) else None)
        if cancelado(self.vid):
            return self._cancelar(pasta)

        _set(self.vid, etapa="cortando", status="preparando o vídeo…", pct=100)
        segs = self._segmentar(arq, pasta)
        arq.unlink(missing_ok=True)
        if not segs:
            raise RuntimeError("não consegui ler o vídeo baixado")
        duracao = segs[-1][2]
        tam = ia_cortes.carregar()["bloco_min"] * 60
        faixas, a = [], 0.0
        while a < duracao:
            b = min(duracao, a + tam)
            if b - a >= 180 or not faixas:
                faixas.append((a, b))
            else:
                faixas[-1] = (faixas[-1][0], b)
            a = b
        _set(self.vid, etapa="ia", blocos=len(faixas), status=f"IA analisando: bloco 1 de {len(faixas)}")
        self._log(f"vídeo pronto ({duracao / 60:.0f} min) — {len(faixas)} blocos para a IA")
        for a, b in faixas:
            usados = [(str(pasta / n), i, f) for n, i, f in segs if f > a and i < b]
            self.editor.fila.put({
                "tipo": "bloco", "canal": chave, "segs": usados, "bloco_ini": a, "bloco_fim": b, "chat": [],
                "layout": (canal_cfg or {}).get("layout", "auto"), "facecam": (canal_cfg or {}).get("facecam"),
                "url": self.url, "nome_bonito": nome_bonito, "vod_id": self.vid,
                "vod_info": {"vod": self.url, "vod_titulo": d["titulo"], "vod_data": d["data"],
                             "vod_offset_seg": ini}})

    def _cancelar(self, pasta):
        _set(self.vid, etapa="cancelado", status="cancelado", fim=datetime.now().isoformat(timespec="seconds"))
        shutil.rmtree(pasta, ignore_errors=True)

    def _baixar(self, pasta, ini, fim, esperado=None):
        cmd = [sys.executable, "-m", "yt_dlp", "--no-warnings", "--no-playlist", "--newline",
               "-f", "best[height<=720]/best", "--concurrent-fragments", "4",
               "-o", str(pasta / "vod.%(ext)s")]
        if ini is not None or fim is not None:
            cmd += ["--download-sections", f"*{hms(ini or 0)}-{hms(fim) if fim else 'inf'}"]
        cmd.append(self.url)
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                encoding="utf-8", errors="replace")
        _set(self.vid, _proc=proc)
        ultimo = []
        for linha in proc.stdout:
            ultimo = (ultimo + [linha.strip()])[-6:]
            m = re.search(r"(\d+(?:\.\d+)?)%", linha)
            if m and "[download]" in linha:
                resto = re.search(r"of\s+~?\s*([\d.]+\w+).*?at\s+([\d.]+\w+/s)(?:.*?ETA\s+([\d:]+))?", linha)
                extra = f" · {resto.group(2)}" + (f" · faltam {resto.group(3)}" if resto.group(3) else "") if resto else ""
                _set(self.vid, pct=float(m.group(1)), status=f"baixando o vídeo: {float(m.group(1)):.0f}%{extra}")
            t = re.search(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)", linha)  # trecho: o ffmpeg informa o tempo baixado
            if t and esperado:
                feito = int(t.group(1)) * 3600 + int(t.group(2)) * 60 + float(t.group(3))
                pct = min(99.0, feito / esperado * 100)
                _set(self.vid, pct=pct, status=f"baixando o vídeo: {pct:.0f}% ({feito / 60:.0f} de {esperado / 60:.0f} min)")
            if cancelado(self.vid):
                break
        proc.wait()
        _set(self.vid, _proc=None)
        arqs = [p for p in pasta.glob("vod.*") if p.suffix not in (".part", ".ytdl")]
        if cancelado(self.vid):
            return arqs[0] if arqs else None
        if proc.returncode != 0 or not arqs:
            erro = next((l for l in reversed(ultimo) if "ERROR" in l), ultimo[-1] if ultimo else "falha no download")
            raise RuntimeError(("o download falhou: " + erro.replace("ERROR: ", ""))[:220])
        return max(arqs, key=lambda p: p.stat().st_size)

    def _segmentar(self, arq, pasta):
        """Corta em pedaços de 60 s (seg_00000.ts...) e devolve [(nome, inicio, fim)] — mesmo formato da gravação."""
        lista_csv = pasta / "segmentos.csv"
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(arq), "-c", "copy",
                        "-f", "segment", "-segment_time", "60", "-segment_format", "mpegts",
                        "-segment_list", str(lista_csv), "-segment_list_type", "csv",
                        str(pasta / "seg_%05d.ts")], check=True)
        saida = []
        with open(lista_csv, newline="") as f:
            for linha in csv.reader(f):
                if len(linha) >= 3 and (pasta / linha[0]).exists():
                    saida.append((linha[0], float(linha[1]), float(linha[2])))
        return saida


def iniciar(editor, cfg, url, ini=None, fim=None, nome=None):
    """Começa a clipar uma live passada. Retorna o id (e não duplica um que já está rodando)."""
    ini_s, fim_s = tempo(ini), tempo(fim)
    if ini_s is not None and fim_s is not None and fim_s <= ini_s:
        raise ValueError("o fim precisa ser depois do início")
    vid = _id(url.strip(), ini_s, fim_s)
    with _LOCK:
        j = JOBS.get(vid)
        if j and j["etapa"] not in ("pronto", "erro", "cancelado"):
            return vid
    Job(editor, cfg, url, ini_s, fim_s, nome).start()
    return vid
