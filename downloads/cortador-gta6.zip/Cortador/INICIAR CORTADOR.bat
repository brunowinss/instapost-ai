@echo off
chcp 65001 >nul
title Cortador GTA 6
cd /d "%~dp0"
echo ============================================
echo   CORTADOR AUTOMATICO DE LIVES - GTA 6
echo   Para parar: feche esta janela ou Ctrl+C
echo ============================================
echo.
python cortes.py
echo.
echo O cortador parou. Pressione uma tecla para fechar.
pause >nul
