"""
Integração com o site instapost-ai.

Quando um corte fica PRONTO (com legenda e card), este módulo:
  1. envia o vídeo para o Cloudinary (mesmo Cloud Name / Preset configurados no site)
  2. agenda nas contas escolhidas (Instagram Reels, Facebook Reels, YouTube Shorts)
  3. marca o corte como "agendado" e move o arquivo para prontos/AGENDADOS

O login é feito uma vez pela janela do app; só o token (vale 7 dias) fica salvo
em site_token.json. A senha não é guardada.
"""
import json
import mimetypes
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent
TOKEN_ARQ = BASE / "site_token.json"
LOCK = threading.Lock()


class ErroSite(Exception):
    pass


def _req(url, metodo="GET", corpo=None, token=None, headers=None, timeout=60):
    h = {"Accept": "application/json"}
    if headers:
        h.update(headers)
    dados = None
    if corpo is not None and not isinstance(corpo, (bytes, bytearray)):
        dados = json.dumps(corpo).encode("utf-8")
        h["Content-Type"] = "application/json"
    elif corpo is not None:
        dados = corpo
    if token:
        h["Authorization"] = f"Bearer {token}"
    r = urllib.request.Request(url, data=dados, method=metodo, headers=h)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            texto = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        texto = e.read().decode("utf-8", "replace")
        try:
            msg = json.loads(texto).get("error") or texto
        except ValueError:
            msg = texto[:200]
        raise ErroSite(f"{e.code}: {msg}") from None
    except urllib.error.URLError as e:
        raise ErroSite(f"sem conexão com {url.split('/api')[0]} ({e.reason})") from None
    try:
        return json.loads(texto)
    except ValueError:
        raise ErroSite(f"resposta inesperada do site: {texto[:120]}") from None


# --------------------------------------------------------------------------
# Sessão com o site
# --------------------------------------------------------------------------
def carregar_token():
    try:
        return json.loads(TOKEN_ARQ.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def conectar(url, usuario, senha):
    """Faz login no site e guarda só o token."""
    url = url.strip().rstrip("/")
    if not url.startswith("http"):
        url = "https://" + url
    r = _req(f"{url}/api/login", "POST", {"username": usuario, "password": senha})
    if not r.get("token"):
        raise ErroSite("o site não devolveu o token de login")
    info = {"url": url, "token": r["token"], "usuario": usuario,
            "expira": (datetime.now() + timedelta(days=6, hours=20)).isoformat(timespec="seconds")}
    TOKEN_ARQ.write_text(json.dumps(info, indent=2), encoding="utf-8")
    return info


def vincular(url, token, usuario="site"):
    """A página Cortar live do site entrega o próprio login para o app (sem digitar senha)."""
    url = url.strip().rstrip("/")
    info = {"url": url, "token": token, "usuario": usuario,
            "expira": (datetime.now() + timedelta(days=6, hours=20)).isoformat(timespec="seconds")}
    TOKEN_ARQ.write_text(json.dumps(info, indent=2), encoding="utf-8")
    return info


def desconectar():
    TOKEN_ARQ.unlink(missing_ok=True)


def sessao():
    s = carregar_token()
    if not s.get("token"):
        raise ErroSite("app não está conectado ao site (conecte na janela do app)")
    if s.get("expira") and datetime.fromisoformat(s["expira"]) < datetime.now():
        raise ErroSite("o login no site expirou (conecte de novo na janela do app)")
    return s


def dados_site():
    """Contas, configuração (Cloudinary) e posts pendentes do site."""
    s = sessao()
    return _req(f"{s['url']}/api/data", token=s["token"], timeout=90)


def contas_do_site():
    d = dados_site()
    contas = []
    for c in d.get("accounts", []):
        contas.append({"id": c.get("accountId"), "nome": c.get("username") or c.get("accountId"),
                       "plataforma": (c.get("platform") or "instagram").lower()})
    return contas


# --------------------------------------------------------------------------
# Upload para o Cloudinary (igual ao site faz: upload sem assinatura com preset)
# --------------------------------------------------------------------------
def enviar_cloudinary(arquivo, nome_cloud, preset):
    arquivo = Path(arquivo)
    if arquivo.stat().st_size > 100 * 1024 * 1024:
        raise ErroSite(f"{arquivo.name} tem mais de 100 MB (limite do Cloudinary grátis)")
    fronteira = "----cortador" + uuid.uuid4().hex
    tipo = mimetypes.guess_type(arquivo.name)[0] or "video/mp4"
    partes = []
    partes.append(f"--{fronteira}\r\nContent-Disposition: form-data; name=\"upload_preset\"\r\n\r\n{preset}\r\n".encode())
    partes.append((f"--{fronteira}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"corte.mp4\"\r\n"
                   f"Content-Type: {tipo}\r\n\r\n").encode())
    partes.append(arquivo.read_bytes())
    partes.append(f"\r\n--{fronteira}--\r\n".encode())
    corpo = b"".join(partes)
    r = _req(f"https://api.cloudinary.com/v1_1/{nome_cloud}/video/upload", "POST", corpo,
             headers={"Content-Type": f"multipart/form-data; boundary={fronteira}"}, timeout=600)
    if r.get("error"):
        raise ErroSite(f"Cloudinary: {r['error'].get('message')}")
    return r["secure_url"]


# --------------------------------------------------------------------------
# Horários: próximos espaços livres para Instagram/Facebook
# --------------------------------------------------------------------------
def proximos_horarios(pendentes_da_conta, horarios, quantidade, minimo_minutos=30):
    """Escolhe os próximos horários livres (hh:mm do dia), depois do último já agendado."""
    ocupados = []
    for p in pendentes_da_conta:
        try:
            ocupados.append(datetime.fromisoformat(p["scheduledAt"].replace("Z", "+00:00")).astimezone().replace(tzinfo=None))
        except (KeyError, ValueError):
            pass
    inicio = datetime.now() + timedelta(minutes=minimo_minutos)
    if ocupados:
        inicio = max(inicio, max(ocupados) + timedelta(minutes=1))
    hs = sorted(datetime.strptime(h, "%H:%M").time() for h in horarios)
    saida, dia = [], inicio.date()
    while len(saida) < quantidade:
        for h in hs:
            t = datetime.combine(dia, h)
            if t >= inicio and len(saida) < quantidade:
                saida.append(t)
        dia += timedelta(days=1)
    return saida


# --------------------------------------------------------------------------
# Agendar um corte pronto
# --------------------------------------------------------------------------
def agendar_corte(meta, arquivo_video, cfg_site, log=print):
    """Sobe o vídeo e agenda em todas as contas escolhidas. Retorna a lista do que foi agendado."""
    s = sessao()
    d = dados_site()
    gc = d.get("globalConfig") or {}
    nome_cloud, preset = (gc.get("cloudinaryName") or "").strip(), (gc.get("cloudinaryPreset") or "").strip()
    if not nome_cloud or not preset:
        raise ErroSite("Cloudinary não configurado no site (Configurações → Cloud Name e Upload Preset)")

    contas_escolhidas = set(cfg_site.get("contas") or [])
    if not contas_escolhidas:
        raise ErroSite("nenhuma conta escolhida para agendar (escolha na janela do app)")
    contas = {c["accountId"]: c for c in d.get("accounts", []) if c.get("accountId") in contas_escolhidas}
    if not contas:
        raise ErroSite("as contas escolhidas não existem mais no site")

    log("site", f"enviando {Path(arquivo_video).name[:60]}... para o Cloudinary")
    url_video = enviar_cloudinary(arquivo_video, nome_cloud, preset)

    legenda = meta.get("legenda_post") or meta.get("faixa") or ""
    titulo_curto = (meta.get("faixa") or legenda.split("#")[0]).strip()[:95]
    horarios = cfg_site.get("horarios") or ["12:00", "18:00", "21:00"]
    pendentes = d.get("scheduledPosts") or d.get("posts") or []
    feitos = []

    for conta_id, conta in contas.items():
        plataforma = (conta.get("platform") or "instagram").lower()
        nome = conta.get("username") or conta_id
        if plataforma == "youtube":
            r = _req(f"{s['url']}/api/youtube/bulk-schedule", "POST", {
                "accountId": conta_id, "horarios": horarios,
                "videos": [{"videoUrl": url_video, "title": titulo_curto, "description": legenda,
                            "isShort": True, "fileName": Path(arquivo_video).name}],
            }, token=s["token"])
        else:
            tipo = "FB_REEL" if plataforma == "facebook" else "REELS"
            meus = [p for p in pendentes if p.get("accountId") == conta_id]
            quando = proximos_horarios(meus, horarios, 1)[0]
            r = _req(f"{s['url']}/api/posts/bulk", "POST", {"posts": [{
                "accountId": conta_id, "mediaType": tipo, "imageUrl": url_video, "caption": legenda,
                "scheduledAt": quando.astimezone().isoformat(), "platform": plataforma,
                "sourceFile": Path(arquivo_video).name,
            }]}, token=s["token"])
            pendentes.append({"accountId": conta_id, "scheduledAt": quando.astimezone().isoformat()})
        quando_txt = (r.get("posts") or [{}])[0].get("scheduledAt", "")
        try:
            quando_txt = datetime.fromisoformat(quando_txt.replace("Z", "+00:00")).astimezone().strftime("%d/%m %H:%M")
        except ValueError:
            pass
        feitos.append({"conta": nome, "plataforma": plataforma, "quando": quando_txt})
        log("site", f"agendado em {plataforma} @{nome} para {quando_txt}")
    return {"url": url_video, "agendamentos": feitos, "em": datetime.now().isoformat(timespec="seconds")}


# --------------------------------------------------------------------------
# Vigia: agenda sozinho todo corte que eu (Claude) deixar pronto
# --------------------------------------------------------------------------
def cortes_prontos_sem_agendar(pasta_cortes):
    for j in sorted(Path(pasta_cortes).glob("*/_dados/*.json")):
        try:
            m = json.loads(j.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        # só os editados depois que o app passou a agendar (editado_em); os antigos ficam de fora
        if m.get("status") == "pronto" and not m.get("agendado") and m.get("pronto") and m.get("editado_em"):
            yield j, m


class Agendador(threading.Thread):
    def __init__(self, cfg, log):
        super().__init__(daemon=True)
        self.cfg = cfg
        self.log = log
        self.ultimo_erro = ""
        self.acordar = threading.Event()

    def cfg_site(self):
        return self.cfg.get("site") or {}

    def run(self):
        while True:
            self.acordar.wait(30)
            self.acordar.clear()
            if self.cfg_site().get("agendar_automatico"):
                self.rodar_uma_vez()

    def agendar_um(self, jpath, meta):
        """Sobe e agenda um corte; move para AGENDADOS. Levanta ErroSite se falhar."""
        video = BASE / meta["pronto"]
        if not video.exists():
            raise ErroSite("o arquivo do corte não está mais na pasta prontos")
        res = agendar_corte(meta, video, self.cfg_site(), self.log)
        destino_dir = video.parent / "AGENDADOS"
        destino_dir.mkdir(exist_ok=True)
        destino = destino_dir / video.name
        video.replace(destino)
        meta["agendado"] = res
        meta["pronto"] = str(destino.relative_to(BASE))
        jpath.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return res

    def rodar_uma_vez(self):
        with LOCK:
            pasta = BASE / self.cfg["pasta_saida"]
            for jpath, meta in cortes_prontos_sem_agendar(pasta):
                if not (BASE / meta["pronto"]).exists():
                    continue  # foi movido (ex.: JA POSTADOS) - não mexe
                try:
                    self.agendar_um(jpath, meta)
                except ErroSite as e:
                    if str(e) != self.ultimo_erro:
                        self.log("site", f"não agendou: {e}")
                    self.ultimo_erro = str(e)
                    return
                self.ultimo_erro = ""
