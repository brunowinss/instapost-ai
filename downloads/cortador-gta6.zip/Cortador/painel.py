"""
Janela do app (painel local). Abre como aplicativo (Edge sem barra de endereço)
em http://127.0.0.1:47653 — essa porta também garante que só um cortador rode por vez.
"""
import collections
import json
import os
import re
import shutil
from urllib.parse import parse_qs, urlparse
import subprocess
import threading
import time
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import site_sync

PORTA = 47653
BASE = Path(__file__).resolve().parent
LOG = collections.deque(maxlen=300)
EDITOR = {"fazendo": "", "fila": 0, "desde": None}
CANAIS = {}  # nome -> {"status": ..., "titulo": ..., "nome_bonito": ...}
GERENCIADOR = None  # cortes.Gerenciador: liga/desliga canais com o app rodando


VERSAO = "1.0"
# sites que podem conversar com o app (o seu InstaPost); outros sites são recusados
ORIGENS_PADRAO = ["https://instapost.brunowins.com"]


def registrar_log(canal, msg):
    LOG.append({"t": datetime.now().strftime("%H:%M:%S"), "canal": canal, "msg": msg})


def _chave(c):
    return ("yt_" + c["youtube"].strip().lstrip("@").lower()) if c.get("youtube") else str(c.get("twitch", "")).lower()


def lista_canais(cfg):
    """Todos os canais da lista (ligados e desligados) com o status atual."""
    saida = []
    for c in cfg.get("canais", []):
        k = _chave(c)
        st = CANAIS.get(k, {})
        ativo = c.get("ativo", True)
        saida.append({
            "chave": k, "nome_bonito": c.get("nome") or k,
            "plataforma": "youtube" if c.get("youtube") else "twitch",
            "usuario": c.get("youtube") or c.get("twitch"),
            "ativo": ativo, "status": st.get("status") or ("aguardando…" if ativo else "monitoramento desligado"),
            "titulo": st.get("titulo", ""),
            **{k: st.get(k) for k in ("gravado_seg", "gravando", "chat_min", "momentos_esperando", "ia_ligada",
                                      "ia_bloco_min", "ia_proximo_em", "ia_etapa", "ia_ultimo", "ultimo_corte",
                                      "n_pronto", "n_rascunho")},
        })
    return saida


def _baixar_pagina(url):
    import urllib.request
    r = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                                             "Accept-Language": "pt-BR,pt;q=0.9"})
    with urllib.request.urlopen(r, timeout=15) as resp:
        return resp.read(600_000).decode("utf-8", "replace")


def _meta(html, prop):
    import html as h
    m = re.search(rf'<meta[^>]+(?:property|name)="{prop}"[^>]+content="([^"]*)"', html) or \
        re.search(rf'<meta[^>]+content="([^"]*)"[^>]+(?:property|name)="{prop}"', html)
    return h.unescape(m.group(1)).strip() if m else ""


def info_do_canal(entrada):
    """Do link (ou usuário) descobre plataforma, usuário e o nome do canal."""
    e = (entrada or "").strip()
    if not e:
        raise ValueError("cole o link do canal")
    plataforma, usuario = None, None
    m = re.search(r"twitch\.tv/([A-Za-z0-9_]{2,30})", e, re.I)
    if m:
        plataforma, usuario = "twitch", m.group(1).lower()
    m = m or None
    if not plataforma:
        m = re.search(r"youtube\.com/(@[\w.\-]{2,60})", e, re.I)
        if m:
            plataforma, usuario = "youtube", m.group(1)
    if not plataforma and re.search(r"(youtube\.com/(live/|watch\?|shorts/)|youtu\.be/)", e, re.I):
        # link de um vídeo/live: abre a página e pega o canal dono do vídeo
        plataforma = "youtube"
        try:
            import yt_dlp
            with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True,
                                   "extract_flat": True}) as ydl:
                info = ydl.extract_info(e if e.startswith("http") else "https://" + e, download=False)
            usuario = info.get("uploader_id") if str(info.get("uploader_id") or "").startswith("@") else None
            if usuario:
                return {"plataforma": "youtube", "usuario": usuario,
                        "nome": info.get("channel") or info.get("uploader") or usuario.lstrip("@")}
        except Exception:
            pass
        raise ValueError("não achei o canal desse vídeo; cole o link do canal (ex.: youtube.com/@canal)")
    if not plataforma and re.search(r"youtube\.com/(channel|c|user)/", e, re.I):
        plataforma = "youtube"
        pagina = _baixar_pagina(e if e.startswith("http") else "https://" + e)
        h = re.search(r'"canonicalBaseUrl":"/(@[^"]+)"', pagina)
        if not h:
            raise ValueError("não achei o @ desse canal do YouTube; cole o link com @ (ex.: youtube.com/@canal)")
        usuario = h.group(1)
    if not plataforma:
        if e.startswith("@"):
            plataforma, usuario = "youtube", e
        elif re.fullmatch(r"[A-Za-z0-9_]{2,30}", e):
            plataforma, usuario = "twitch", e.lower()
        else:
            raise ValueError("não reconheci esse link; use um link da Twitch ou do YouTube")

    nome = ""
    try:
        if plataforma == "twitch":
            pagina = _baixar_pagina(f"https://www.twitch.tv/{usuario}")
            nome = re.sub(r"\s*-\s*(Ao vivo na |Live on |En vivo en )?Twitch\s*$", "", _meta(pagina, "og:title"), flags=re.I)
        else:
            pagina = _baixar_pagina(f"https://www.youtube.com/{usuario}")
            nome = re.sub(r"\s*-\s*YouTube\s*$", "", _meta(pagina, "og:title"))
    except Exception:
        nome = ""
    if not nome or nome.lower() in ("twitch", "youtube"):
        nome = usuario.lstrip("@")
    return {"plataforma": plataforma, "usuario": usuario, "nome": nome}


def origem_ok(origem, cfg):
    """Só o seu site (e o site rodando no próprio PC) pode conversar com o app."""
    if not origem:
        return False
    o = origem.lower().rstrip("/")
    if re.match(r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$", o):
        return True
    if re.match(r"^https://[a-z0-9-]+\.onrender\.com$", o):
        return True
    permitidos = ORIGENS_PADRAO + [x.lower().rstrip("/") for x in (cfg.get("site") or {}).get("origens", [])]
    tok = site_sync.carregar_token()
    if tok.get("url"):
        permitidos.append(tok["url"].lower().rstrip("/"))
    return o in permitidos


_CACHE = {}  # caminho -> (mtime, meta)


def todos_metas(cfg):
    """Lê os dados dos cortes; só relê o arquivo que mudou (antes relia tudo a cada 3 s)."""
    vistos = set()
    for j in (BASE / cfg["pasta_saida"]).glob("**/_dados/*.json"):
        vistos.add(j)
        try:
            mt = j.stat().st_mtime
            c = _CACHE.get(j)
            if not c or c[0] != mt:
                c = (mt, json.loads(j.read_text(encoding="utf-8")))
                _CACHE[j] = c
            yield j, c[1]
        except (OSError, ValueError):
            continue
    for velho in set(_CACHE) - vistos:
        _CACHE.pop(velho, None)


def _baixado(m):
    return "Cut.Pro" in (m.get("origem") or "") or "baixado" in (m.get("origem") or "")


def soltos(cfg):
    """Vídeos que VOCÊ colocou numa pasta rascunhos/ (baixados de outro lugar) e que o app não cortou."""
    raiz = BASE / cfg["pasta_saida"]
    usados = set()
    for j, m in todos_metas(cfg):
        if m.get("rascunho"):
            usados.add(str((BASE / m["rascunho"]).resolve()).lower())
    saida = []
    for arq in list(raiz.glob("*/*/rascunhos/*.mp4")) + list(raiz.glob("*/rascunhos/*.mp4")):
        if str(arq.resolve()).lower() in usados:
            continue
        rel = arq.relative_to(raiz)
        partes = rel.parts  # Streamer/dia/rascunhos/x.mp4  ou  dia/rascunhos/x.mp4
        streamer, dia = (partes[0], partes[1]) if len(partes) == 4 else ("", partes[0])
        import hashlib
        ident = "ext_" + hashlib.md5(str(rel).lower().encode("utf-8")).hexdigest()[:12]
        saida.append({"id": ident, "arq": arq, "streamer": streamer, "dia": dia})
    return saida


def miniatura_solta(item):
    pasta = BASE / cfg_pasta_thumbs()
    pasta.mkdir(exist_ok=True)
    jpg = pasta / f"{item['id']}.jpg"
    arq = item["arq"]
    if not jpg.exists() or jpg.stat().st_mtime < arq.stat().st_mtime:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", "2", "-i", str(arq), "-frames:v", "1",
                        "-vf", "scale=270:-2", "-q:v", "5", str(jpg)], capture_output=True, timeout=30)
    return jpg if jpg.exists() else None


def cfg_pasta_thumbs():
    return "_miniaturas"


def miniatura(j, m):
    """Imagem pequena do corte (gerada uma vez e guardada em _dados)."""
    arq = arquivo_do_corte(j, m)
    if not arq:
        return None
    jpg = j.parent / f"{m.get('nome')}_thumb.jpg"
    if not jpg.exists() or jpg.stat().st_mtime < arq.stat().st_mtime:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", "2", "-i", str(arq), "-frames:v", "1",
                        "-vf", "scale=270:-2", "-q:v", "5", str(jpg)], capture_output=True, timeout=30)
    return jpg if jpg.exists() else None


def arquivo_do_corte(j, m):
    """Arquivo de vídeo a mostrar: o editado (se existir) ou o rascunho."""
    for chave in ("pronto", "rascunho"):
        if m.get(chave):
            p = BASE / m[chave]
            if p.is_file():
                return p
    return None


def listar_cortes(cfg, tipo):
    saida = []
    if tipo == "rascunhos":  # Esperando edição: os que você baixou e jogou na pasta
        for it in soltos(cfg):
            try:
                quando = datetime.fromtimestamp(it["arq"].stat().st_mtime).isoformat(timespec="seconds")
            except OSError:
                quando = ""
            saida.append({"id": it["id"], "canal": it["streamer"] or "sem streamer", "dia": it["dia"],
                          "origem": "baixado", "cortado": quando, "editado": "", "quando": quando, "estado": "rascunho",
                          "titulo": "", "faixa": "", "fala": it["arq"].stem, "motivos": [], "forca": None,
                          "agendado": None, "novo": False, "video": f"/video/{it['id']}", "usado": "",
                          "arquivo": it["arq"].name, "thumb": f"/thumb/{it['id']}"})
    for j, m in todos_metas(cfg):
        if tipo == "rascunhos" and m.get("status") != "rascunho":  # tudo que falta editar
            continue
        if tipo == "clipados" and (_baixado(m) or m.get("status") != "rascunho"):  # só o que o app clipou e falta editar
            continue
        if tipo == "prontos" and not (m.get("status") == "pronto" and not m.get("agendado")):
            continue
        if tipo == "prontos" and not (BASE / m.get("pronto", "")).is_file():
            continue  # movido pra JA POSTADOS ou outra pasta
        if tipo == "agendados" and not m.get("agendado"):
            continue
        arq = arquivo_do_corte(j, m)
        if not arq:
            continue
        # de onde veio e quando foi cortado (para a lista do site ficar clara)
        motivos = " ".join(m.get("motivos") or [])
        if m.get("ia_nota") is not None:
            origem = f"IA nota {float(m['ia_nota']):.0f}"
        elif "Cut.Pro" in (m.get("origem") or ""):
            origem = "Cut.Pro"
        elif "voz" in motivos:
            origem = "pico de voz"
        elif motivos:
            origem = "pico do chat"
        else:
            origem = "manual"
        try:
            quando = m.get("horario") or datetime.fromtimestamp((j.parent / m.get("bruto", "")).stat().st_mtime).isoformat(timespec="seconds")
        except OSError:
            quando = ""
        saida.append({
            "dia": j.parent.parent.name, "origem": origem, "cortado": quando,
            "estado": "agendado" if m.get("agendado") else ("pronto" if m.get("status") == "pronto" else "rascunho"),
            "editado": m.get("editado_em") or "",
            "id": m.get("nome"), "canal": m.get("nome_bonito") or m.get("canal"),
            "titulo": m.get("legenda_post") or "", "faixa": m.get("faixa") or "",
            "fala": (m.get("fala_texto") or "")[:280], "motivos": m.get("motivos") or [],
            "forca": m.get("forca_do_pico"), "quando": m.get("horario") or "",
            "agendado": (m.get("agendado") or {}).get("agendamentos"),
            "novo": bool(m.get("editado_em")), "video": f"/video/{m.get('nome')}",
            "usado": m.get("usado_no_site") or "",
            "arquivo": arquivo_do_corte(j, m).name,
            "thumb": f"/thumb/{m.get('nome')}?v={int(arq.stat().st_mtime)}",
        })
    for c in saida:
        c["quando"] = c["quando"] or c["cortado"]
    saida.sort(key=lambda c: (c["dia"], c["editado"] if tipo == "prontos" else "", c["quando"] or c["id"]), reverse=True)
    return saida[:500]


def contar(cfg):
    c = {"rascunhos": len(soltos(cfg)), "clipados": 0, "prontos": 0, "agendados": 0}
    ultimos = []
    for j, m in todos_metas(cfg):
        if m.get("status") == "rascunho":
            c["rascunhos"] += 1
            if not _baixado(m):
                c["clipados"] += 1
        elif m.get("agendado"):
            c["agendados"] += 1
            ultimos.append(m)
        elif m.get("status") == "pronto" and (BASE / m.get("pronto", "")).is_file():
            c["prontos"] += 1
            ultimos.append(m)
    ultimos.sort(key=lambda m: (m.get("agendado") or {}).get("em") or m.get("horario") or "", reverse=True)
    lista = [{"titulo": m.get("legenda_post") or m.get("faixa") or m.get("nome"),
              "canal": m.get("nome_bonito") or m.get("canal"),
              "agendado": m.get("agendado", {}).get("agendamentos") if m.get("agendado") else None}
             for m in ultimos[:30]]
    return c, lista


def salvar_cfg(cfg, caminho):
    Path(caminho).write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def iniciar(cfg, caminho_cfg, agendador):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _cors(self):
            origem = self.headers.get("Origin")
            if origem_ok(origem, cfg):
                self.send_header("Access-Control-Allow-Origin", origem)
                self.send_header("Vary", "Origin")
                self.send_header("Access-Control-Allow-Private-Network", "true")

        def _origem_proibida(self):
            """Pedido vindo de outro site (não o seu) é recusado."""
            origem = self.headers.get("Origin")
            return bool(origem) and not origem_ok(origem, cfg)

        def do_OPTIONS(self):
            self.send_response(204)
            self._cors()
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Max-Age", "600")
            self.end_headers()

        def _json(self, obj, code=200):
            dados = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self._cors()
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(dados)))
            self.end_headers()
            self.wfile.write(dados)

        def _video(self, arq):
            tam = arq.stat().st_size
            ini, fim = 0, tam - 1
            rng = self.headers.get("Range")
            m = re.match(r"bytes=(\d*)-(\d*)", rng or "")
            if m:
                if m.group(1):
                    ini = int(m.group(1))
                    fim = int(m.group(2)) if m.group(2) else tam - 1
                else:
                    ini = max(0, tam - int(m.group(2)))
                fim = min(fim, tam - 1)
            self.send_response(206 if m else 200)
            self._cors()
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(fim - ini + 1))
            if m:
                self.send_header("Content-Range", f"bytes {ini}-{fim}/{tam}")
            self.end_headers()
            with open(arq, "rb") as f:
                f.seek(ini)
                falta = fim - ini + 1
                try:
                    while falta > 0:
                        bloco = f.read(min(1 << 16, falta))
                        if not bloco:
                            break
                        self.wfile.write(bloco)
                        falta -= len(bloco)
                except (ConnectionError, OSError):
                    pass

        def _corpo(self):
            n = int(self.headers.get("Content-Length") or 0)
            try:
                return json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return {}

        def do_GET(self):
            if self._origem_proibida():
                return self._json({"erro": "origem não permitida"}, 403)
            url = urlparse(self.path)
            if url.path == "/api/ping":
                return self._json({"app": "cortador", "versao": VERSAO,
                                   "vinculado": bool(site_sync.carregar_token().get("token"))})
            if url.path == "/api/canal_info":
                try:
                    return self._json(info_do_canal((parse_qs(url.query).get("entrada") or [""])[0]))
                except ValueError as e:
                    return self._json({"erro": str(e)}, 400)
                except Exception as e:
                    return self._json({"erro": f"não consegui abrir a página do canal ({e})"}, 400)
            if url.path == "/api/cortes":
                tipo = (parse_qs(url.query).get("tipo") or ["prontos"])[0]
                return self._json({"cortes": listar_cortes(cfg, tipo)})
            if url.path.startswith("/thumb/"):
                nome = url.path.split("/", 2)[2]
                for j, m in todos_metas(cfg):
                    if m.get("nome") == nome:
                        jpg = miniatura(j, m)
                        if jpg:
                            dados = jpg.read_bytes()
                            self.send_response(200)
                            self._cors()
                            self.send_header("Content-Type", "image/jpeg")
                            self.send_header("Cache-Control", "max-age=86400")
                            self.send_header("Content-Length", str(len(dados)))
                            self.end_headers()
                            self.wfile.write(dados)
                            return
                for it in soltos(cfg) if nome.startswith("ext_") else []:
                    if it["id"] == nome:
                        jpg = miniatura_solta(it)
                        if jpg:
                            dados = jpg.read_bytes()
                            self.send_response(200)
                            self._cors()
                            self.send_header("Content-Type", "image/jpeg")
                            self.send_header("Cache-Control", "max-age=86400")
                            self.send_header("Content-Length", str(len(dados)))
                            self.end_headers()
                            self.wfile.write(dados)
                            return
                return self._json({"erro": "sem miniatura"}, 404)
            if url.path.startswith("/video/"):
                nome = url.path.split("/", 2)[2]
                for j, m in todos_metas(cfg):
                    if m.get("nome") == nome:
                        arq = arquivo_do_corte(j, m)
                        if arq:
                            return self._video(arq)
                for it in soltos(cfg) if nome.startswith("ext_") else []:
                    if it["id"] == nome:
                        return self._video(it["arq"])
                return self._json({"erro": "corte não encontrado"}, 404)
            if self.path == "/":
                dados = HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(dados)))
                self.end_headers()
                self.wfile.write(dados)
            elif self.path == "/api/estado":
                cont, lista = contar(cfg)
                tok = site_sync.carregar_token()
                self._json({
                    "canais": lista_canais(cfg),
                    "cortador_ligado": cfg.get("cortador_ligado", True),
                    "contagens": cont, "cortes": lista, "log": list(LOG)[-80:],
                    "site": {"conectado": bool(tok.get("token")), "url": tok.get("url", ""),
                             "usuario": tok.get("usuario", ""), "expira": tok.get("expira", "")},
                    "cfg_site": cfg.get("site") or {},
                    "erro_agendador": agendador.ultimo_erro,
                    "editor": {**EDITOR, "ha_seg": round(time.time() - EDITOR["desde"]) if EDITOR.get("desde") else 0},
                })
            elif self.path == "/api/ia":
                import ia_cortes
                self._json({**ia_cortes.publico(), "provedores": list(ia_cortes.PROVEDORES)})
            elif self.path == "/api/contas":
                try:
                    self._json({"contas": site_sync.contas_do_site()})
                except site_sync.ErroSite as e:
                    self._json({"erro": str(e)}, 400)
            else:
                self._json({"erro": "não encontrado"}, 404)

        def do_POST(self):
            if self._origem_proibida():
                return self._json({"erro": "origem não permitida"}, 403)
            b = self._corpo()
            try:
                if self.path == "/api/vincular":
                    origem = self.headers.get("Origin") or b.get("url", "")
                    if not b.get("token") or not origem:
                        return self._json({"erro": "faltou o login do site"}, 400)
                    antes = site_sync.carregar_token()
                    site_sync.vincular(origem, b["token"], b.get("usuario") or "site")
                    if antes.get("url") != origem.rstrip("/") or not antes.get("token"):
                        registrar_log("site", f"app vinculado ao site {origem}")
                    self._json({"ok": True})
                elif self.path == "/api/marcar_usado":
                    # corte escolhido numa tela de publicação do site (Nova publicação / em massa)
                    ids = set(b.get("ids") or [])
                    n = 0
                    for j, m in todos_metas(cfg):
                        if m.get("nome") in ids:
                            m["usado_no_site"] = datetime.now().isoformat(timespec="seconds")
                            j.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
                            n += 1
                    registrar_log("site", f"{n} corte(s) enviados para uma tela de publicação do site")
                    self._json({"ok": True, "marcados": n})
                elif self.path == "/api/cortador":
                    # botão geral: Ligar / Parar cortador (todas as lives de uma vez)
                    cfg["cortador_ligado"] = bool(b.get("ligado"))
                    salvar_cfg(cfg, caminho_cfg)
                    registrar_log("sistema", "CORTADOR LIGADO - monitorando as lives" if cfg["cortador_ligado"]
                                  else "CORTADOR PARADO - nenhuma live está sendo gravada")
                    if GERENCIADOR:
                        GERENCIADOR.aplicar()
                    self._json({"ok": True, "ligado": cfg["cortador_ligado"]})
                elif self.path == "/api/canais":
                    acao = b.get("acao")
                    canais = cfg.setdefault("canais", [])
                    chave = str(b.get("chave") or "").lower()
                    achar = lambda: next((c for c in canais if _chave(c) == chave), None)
                    if acao == "monitorar":
                        c = achar()
                        if not c:
                            return self._json({"erro": "canal não encontrado"}, 404)
                        c["ativo"] = bool(b.get("ativo"))
                        registrar_log(chave, "monitoramento ligado" if c["ativo"] else "monitoramento desligado no site")
                    elif acao == "remover":
                        c = achar()
                        if c:
                            canais.remove(c)
                            registrar_log(chave, "canal removido da lista")
                    elif acao == "adicionar":
                        plat = b.get("plataforma")
                        usuario = re.sub(r"^https?://(www\.)?(twitch\.tv/|youtube\.com/)", "", str(b.get("usuario") or "").strip()).strip("/ ")
                        usuario = usuario.split("/")[0]
                        if not usuario or plat not in ("twitch", "youtube"):
                            return self._json({"erro": "informe a plataforma e o usuário do canal"}, 400)
                        novo = {plat: ("@" + usuario.lstrip("@")) if plat == "youtube" else usuario.lower(),
                                "nome": (b.get("nome") or usuario.lstrip("@")).strip(), "layout": "auto", "ativo": True}
                        if any(_chave(c) == _chave(novo) for c in canais):
                            return self._json({"erro": "esse canal já está na lista"}, 400)
                        canais.append(novo)
                        registrar_log(_chave(novo), f"canal adicionado: {novo['nome']}")
                    else:
                        return self._json({"erro": "ação inválida"}, 400)
                    salvar_cfg(cfg, caminho_cfg)
                    if GERENCIADOR:
                        GERENCIADOR.aplicar()
                    self._json({"ok": True})
                elif self.path == "/api/agendar":
                    nome = b.get("id")
                    alvo = next(((j, m) for j, m in todos_metas(cfg) if m.get("nome") == nome), None)
                    if not alvo:
                        return self._json({"erro": "corte não encontrado"}, 404)
                    j, m = alvo
                    if m.get("status") != "pronto":
                        return self._json({"erro": "esse corte ainda não foi editado (sem legenda e card)"}, 400)
                    if m.get("agendado"):
                        return self._json({"erro": "esse corte já foi agendado"}, 400)
                    with site_sync.LOCK:
                        res = agendador.agendar_um(j, m)
                    self._json({"ok": True, "agendamentos": res["agendamentos"]})
                elif self.path == "/api/conectar":
                    info = site_sync.conectar(b.get("url", ""), b.get("usuario", ""), b.get("senha", ""))
                    registrar_log("site", f"conectado em {info['url']} como {info['usuario']}")
                    self._json({"ok": True})
                elif self.path == "/api/desconectar":
                    site_sync.desconectar()
                    registrar_log("site", "desconectado do site")
                    self._json({"ok": True})
                elif self.path == "/api/salvar_site":
                    s = cfg.setdefault("site", {})
                    s["contas"] = [str(x) for x in b.get("contas", [])]
                    s["horarios"] = [h for h in b.get("horarios", []) if len(h) == 5 and h[2] == ":"] or ["12:00", "18:00", "21:00"]
                    s["agendar_automatico"] = bool(b.get("agendar_automatico"))
                    salvar_cfg(cfg, caminho_cfg)
                    registrar_log("site", f"agendamento salvo: {len(s['contas'])} conta(s), horários {', '.join(s['horarios'])}")
                    self._json({"ok": True})
                elif self.path == "/api/ia":
                    # a chave fica só neste PC (ia_config.json); o site nunca a recebe de volta
                    import ia_cortes
                    try:
                        ia_cortes.salvar(b)
                    except ia_cortes.ErroIA as e:
                        return self._json({"erro": str(e)}, 400)
                    teste = None
                    if ia_cortes.carregar().get("chave") and b.get("testar", True):
                        try:
                            ia_cortes.testar()
                            teste = "ok"
                        except ia_cortes.ErroIA as e:
                            teste = str(e)
                    registrar_log("ia", "IA dos cortes: " + ("funcionando" if teste == "ok" else f"configuração salva ({teste or 'sem chave'})"))
                    self._json({**ia_cortes.publico(), "teste": teste})
                elif self.path == "/api/agendar_agora":
                    threading.Thread(target=agendador.rodar_uma_vez, daemon=True).start()
                    self._json({"ok": True})
                elif self.path == "/api/abrir":
                    # abre a pasta de cortes (ou a pasta de um streamer: cortes\<Streamer>)
                    alvo = BASE / cfg["pasta_saida"]
                    if b.get("canal"):
                        alvo = alvo / re.sub(r'[\\/:*?"<>|]', "", str(b["canal"])).strip(" .")
                    alvo.mkdir(parents=True, exist_ok=True)
                    os.startfile(alvo)
                    self._json({"ok": True})
                else:
                    self._json({"erro": "não encontrado"}, 404)
            except site_sync.ErroSite as e:
                self._json({"erro": str(e)}, 400)

    srv = ThreadingHTTPServer(("127.0.0.1", PORTA), H)  # OSError se já tiver outro rodando
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def abrir_janela():
    """Abre o app: a página Cortar live do seu site (se já foi vinculado); senão o painel local."""
    tok = site_sync.carregar_token()
    url = f"{tok['url']}/#cortar-live" if tok.get("url") else f"http://127.0.0.1:{PORTA}/"
    for edge in (shutil.which("msedge"),
                 r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                 r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"):
        if edge and os.path.exists(edge):
            subprocess.Popen([edge, f"--app={url}", "--window-size=1150,820"])
            return
    webbrowser.open(url)


HTML = r"""<!doctype html>
<html lang="pt-br"><head><meta charset="utf-8"><title>Cortador GTA 6</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0f1115;--card:#171a21;--borda:#262b36;--txt:#e7e9ee;--fraco:#8a93a6;--verde:#22c55e;--verm:#ef4444;--azul:#6366f1;--amar:#eab308}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);font:14px/1.4 system-ui,Segoe UI,sans-serif}
header{display:flex;align-items:center;gap:12px;padding:14px 20px;border-bottom:1px solid var(--borda)}
header h1{font-size:18px;margin:0}header .tag{background:#7f1d1d;color:#fecaca;padding:2px 8px;border-radius:99px;font-size:12px}
main{display:grid;grid-template-columns:1.1fr 1fr;gap:16px;padding:16px 20px}
@media(max-width:900px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--borda);border-radius:12px;padding:14px 16px}
.card h2{font-size:14px;margin:0 0 10px;color:var(--fraco);text-transform:uppercase;letter-spacing:.04em}
.canal{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--borda)}.canal:last-child{border:0}
.bola{width:9px;height:9px;border-radius:50%;background:#4b5563;flex:none}.bola.on{background:var(--verm);box-shadow:0 0 8px var(--verm)}
.canal small{color:var(--fraco);display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:420px}
.nums{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.num{background:#11141a;border:1px solid var(--borda);border-radius:10px;padding:10px;text-align:center;cursor:pointer}
.num b{display:block;font-size:26px}.num span{color:var(--fraco);font-size:12px}
.corte{padding:7px 0;border-bottom:1px solid var(--borda);font-size:13px}.corte:last-child{border:0}.corte .ag{color:var(--verde);font-size:12px}.corte .pend{color:var(--amar);font-size:12px}
input,button{font:inherit}input[type=text],input[type=password]{width:100%;background:#0b0d11;border:1px solid var(--borda);color:var(--txt);border-radius:8px;padding:8px 10px;margin:4px 0 8px}
button{background:var(--azul);color:#fff;border:0;border-radius:8px;padding:8px 14px;cursor:pointer}button.sec{background:#2a2f3b}button:disabled{opacity:.5}
.conta{display:flex;gap:8px;align-items:center;padding:4px 0}.plat{font-size:11px;color:var(--fraco);border:1px solid var(--borda);border-radius:6px;padding:0 6px}
#log{font:12px/1.5 Consolas,monospace;max-height:260px;overflow:auto;background:#0b0d11;border-radius:8px;padding:8px}
#log div span{color:var(--fraco)}.erro{color:#fca5a5;font-size:13px;margin:6px 0}.ok{color:#86efac;font-size:13px}
.linha{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.lista{max-height:300px;overflow:auto}
</style></head><body>
<header><h1>✂️ Cortador GTA 6</h1><span class="tag">AO VIVO</span><span id="hora" style="margin-left:auto;color:var(--fraco)"></span></header>
<main>
 <div style="display:grid;gap:16px;align-content:start">
  <section class="card"><h2>Lives monitoradas</h2><div id="canais">carregando…</div></section>
  <section class="card"><h2>Cortes</h2>
   <div class="nums">
    <div class="num" onclick="abrir('rascunhos')"><b id="n-r">0</b><span>esperando edição<br>(peça pro Claude)</span></div>
    <div class="num" onclick="abrir('prontos')"><b id="n-p">0</b><span>editados (novos)<br>aguardando agendar</span></div>
    <div class="num" onclick="abrir('agendados')"><b id="n-a">0</b><span>agendados<br>no site</span></div>
   </div>
   <div class="lista" id="cortes" style="margin-top:10px"></div>
  </section>
 </div>
 <div style="display:grid;gap:16px;align-content:start">
  <section class="card"><h2>Seu site (instapost-ai)</h2><div id="site"></div></section>
  <section class="card" id="card-ag" style="display:none"><h2>Onde agendar</h2>
   <div id="contas" class="lista">carregando contas…</div>
   <div style="margin-top:8px">Horários dos posts (por dia):</div>
   <input type="text" id="horarios" placeholder="12:00, 18:00, 21:00">
   <label class="linha"><input type="checkbox" id="auto"> Agendar sozinho assim que o corte ficar pronto</label>
   <div class="linha" style="margin-top:10px"><button onclick="salvar()">Salvar</button><button class="sec" onclick="agora()">Agendar prontos agora</button></div>
   <div id="msg-ag"></div>
  </section>
  <section class="card"><h2>O que está acontecendo</h2><div id="log"></div></section>
 </div>
</main>
<script>
let contasCarregadas=false, cfgSite={};
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function api(p,b){const r=await fetch(p,b?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}:{});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.erro||r.status);return j}
function abrir(q){api('/api/abrir',{qual:q})}
async function atualizar(){
 let e; try{e=await api('/api/estado')}catch(_){return}
 $('hora').textContent=new Date().toLocaleTimeString('pt-BR');
 $('canais').innerHTML=e.canais.length?e.canais.map(c=>`<div class="canal"><span class="bola ${c.status==='gravando'?'on':''}"></span><div><b>${esc(c.nome_bonito||c.nome)}</b> <span class="plat">${esc(c.plataforma||'')}</span><small>${c.status==='gravando'?'🔴 gravando e cortando — '+esc(c.titulo||''):esc(c.status||'aguardando')}</small></div></div>`).join(''):'nenhum canal';
 $('n-r').textContent=e.contagens.rascunhos;$('n-p').textContent=e.contagens.prontos;$('n-a').textContent=e.contagens.agendados;
 $('cortes').innerHTML=e.cortes.map(c=>`<div class="corte">${esc(c.titulo)}<br>${c.agendado?'<span class="ag">✔ agendado: '+c.agendado.map(a=>esc(a.plataforma+' @'+a.conta+' '+a.quando)).join(' · ')+'</span>':'<span class="pend">⏳ aguardando agendar</span>'}</div>`).join('')||'<span style="color:var(--fraco)">nenhum corte editado ainda</span>';
 $('log').innerHTML=e.log.map(l=>`<div><span>${l.t} [${esc(l.canal)}]</span> ${esc(l.msg)}</div>`).join('');$('log').scrollTop=1e9;
 const s=e.site;
 if(s.conectado){
  if(!$('site').dataset.on){$('site').dataset.on=1;$('site').innerHTML=`<div class="ok">✔ Conectado em ${esc(s.url)} como ${esc(s.usuario)}</div><div style="color:var(--fraco);font-size:12px">login vale até ${esc(s.expira.replace('T',' '))}</div><div id="erro-ag" class="erro"></div><button class="sec" onclick="sair()">Desconectar</button>`;$('card-ag').style.display='';}
  $('erro-ag').textContent=e.erro_agendador?('⚠ '+e.erro_agendador):'';
  cfgSite=e.cfg_site; if(!contasCarregadas)carregarContas();
 }else if($('site').dataset.on!=='0'){
  $('site').dataset.on='0';$('card-ag').style.display='none';
  $('site').innerHTML=`Endereço do site<input type="text" id="url" placeholder="https://seusite.onrender.com">Usuário<input type="text" id="usr">Senha<input type="password" id="pwd"><button onclick="conectar()">Conectar</button><div id="msg-site"></div><div style="color:var(--fraco);font-size:12px;margin-top:6px">A senha não fica salva; só o login (vale 7 dias).</div>`;
 }
}
async function conectar(){try{await api('/api/conectar',{url:$('url').value,usuario:$('usr').value,senha:$('pwd').value});$('site').dataset.on='';contasCarregadas=false;atualizar()}catch(err){$('msg-site').innerHTML='<div class="erro">'+esc(err.message)+'</div>'}}
async function sair(){await api('/api/desconectar',{});contasCarregadas=false;atualizar()}
async function carregarContas(){
 contasCarregadas=true;
 try{const r=await api('/api/contas');const sel=new Set(cfgSite.contas||[]);
  $('contas').innerHTML=r.contas.map(c=>`<label class="conta"><input type="checkbox" value="${esc(c.id)}" ${sel.has(String(c.id))?'checked':''}> <span class="plat">${esc(c.plataforma)}</span> ${esc(c.nome)}</label>`).join('')||'nenhuma conta no site';
  $('horarios').value=(cfgSite.horarios||['12:00','18:00','21:00']).join(', ');$('auto').checked=!!cfgSite.agendar_automatico;
 }catch(err){$('contas').innerHTML='<div class="erro">'+esc(err.message)+'</div>';contasCarregadas=false}
}
async function salvar(){
 const contas=[...document.querySelectorAll('#contas input:checked')].map(i=>i.value);
 const horarios=$('horarios').value.split(/[,; ]+/).map(h=>h.trim()).filter(Boolean).map(h=>h.length===4?'0'+h:h);
 try{await api('/api/salvar_site',{contas,horarios,agendar_automatico:$('auto').checked});$('msg-ag').innerHTML='<div class="ok">Salvo.</div>'}catch(err){$('msg-ag').innerHTML='<div class="erro">'+esc(err.message)+'</div>'}
}
async function agora(){await api('/api/agendar_agora',{});$('msg-ag').innerHTML='<div class="ok">Agendando os prontos… acompanhe ao lado.</div>'}
atualizar();setInterval(atualizar,3000);
</script></body></html>"""
