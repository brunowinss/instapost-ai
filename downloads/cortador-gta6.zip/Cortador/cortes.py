"""
Cortador automático de lives (Twitch).

Para cada canal do config.json:
  1. checa se está ao vivo
  2. grava a live em pedaços de 60s (streamlink -> ffmpeg)
  3. lê o chat (anônimo, sem login) e detecta picos de mensagens
  4. quando dá pico, corta [pico - antes, pico + depois]
  5. transforma em vídeo vertical 9:16 com legenda automática (Whisper)

Uso:
  python cortes.py                      # roda com config.json
  python cortes.py --teste video.mp4 120  # testa o editor: corta o vídeo no segundo 120
"""
import argparse
import collections
import csv
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import queue
import random
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent

# DLLs da CUDA instaladas via pip (nvidia-cublas-cu12 / nvidia-cudnn-cu12) para o Whisper usar a GPU
try:
    import nvidia
    for _raiz in nvidia.__path__:
        for _bin in Path(_raiz).glob("*/bin"):
            os.add_dll_directory(str(_bin))
            os.environ["PATH"] = str(_bin) + os.pathsep + os.environ["PATH"]
except Exception:
    pass
LOCK_PRINT = threading.Lock()


def log(canal, msg):
    with LOCK_PRINT:
        linha = f"[{datetime.now():%H:%M:%S}] [{canal}] {msg}"
        try:
            print(linha, flush=True)
        except UnicodeEncodeError:  # console sem UTF-8 (emoji no título da IA)
            enc = getattr(sys.stdout, "encoding", None) or "ascii"
            print(linha.encode(enc, "replace").decode(enc), flush=True)
    try:
        import painel
        painel.registrar_log(canal, msg)
    except Exception:
        pass


def status_canal(canal, **campos):
    try:
        import painel
        painel.CANAIS.setdefault(canal, {}).update(campos)
    except Exception:
        pass


def status_editor(fazendo, fila):
    try:
        import painel
        painel.EDITOR.update(fazendo=fazendo, fila=fila, desde=time.time() if fazendo else None)
    except Exception:
        pass


def contar_corte(canal, tipo, titulo):
    """Guarda o último corte e quantos saíram nesta sessão do app (para mostrar no site)."""
    try:
        import painel
        st = painel.CANAIS.setdefault(canal, {})
        st[f"n_{tipo}"] = st.get(f"n_{tipo}", 0) + 1
        st["ultimo_corte"] = {"hora": datetime.now().strftime("%H:%M"), "tipo": tipo, "titulo": titulo}
    except Exception:
        pass


def carregar_config(caminho):
    with open(caminho, encoding="utf-8") as f:
        return json.load(f)


# --------------------------------------------------------------------------
# Chat da Twitch (IRC anônimo)
# --------------------------------------------------------------------------
class ChatTwitch(threading.Thread):
    def __init__(self, canal):
        super().__init__(daemon=True)
        self.canal = canal.lower()
        self.msgs = collections.deque()  # (tempo, texto)
        self.lock = threading.Lock()
        self.parar = threading.Event()

    def run(self):
        while not self.parar.is_set():
            try:
                self._conectar_e_ler()
            except Exception as e:
                log(self.canal, f"chat caiu ({e}), reconectando...")
                time.sleep(5)

    def _conectar_e_ler(self):
        s = socket.create_connection(("irc.chat.twitch.tv", 6667), timeout=300)
        s.sendall(b"NICK justinfan%d\r\n" % (int(time.time()) % 100000))
        s.sendall(f"JOIN #{self.canal}\r\n".encode())
        buf = b""
        while not self.parar.is_set():
            dados = s.recv(4096)
            if not dados:
                raise ConnectionError("conexão fechada")
            buf += dados
            *linhas, buf = buf.split(b"\r\n")
            for l in linhas:
                linha = l.decode("utf-8", "ignore")
                if linha.startswith("PING"):
                    s.sendall(b"PONG :tmi.twitch.tv\r\n")
                    continue
                m = re.search(r"PRIVMSG #\S+ :(.*)$", linha)
                if m:
                    with self.lock:
                        self.msgs.append((time.time(), m.group(1)))
        s.close()

    def janela(self, inicio, fim):
        with self.lock:
            # descarta mensagens com mais de 10 min
            limite = time.time() - 1200
            while self.msgs and self.msgs[0][0] < limite:
                self.msgs.popleft()
            return [txt for t, txt in self.msgs if inicio <= t < fim]

    def com_tempo(self, inicio, fim):
        self.janela(inicio, fim)  # aproveita a limpeza
        with self.lock:
            return sorted((t, txt) for t, txt in self.msgs if inicio <= t < fim)


class ChatYouTube(ChatTwitch):
    """Lê o chat ao vivo do YouTube usando o yt-dlp (que vai escrevendo um .json)."""

    def __init__(self, canal, video_id):
        super().__init__(canal)
        self.video_id = video_id
        self.proc = None

    def run(self):
        pasta = BASE / "gravacao" / self.canal / "_chat"
        while not self.parar.is_set():
            shutil.rmtree(pasta, ignore_errors=True)
            pasta.mkdir(parents=True, exist_ok=True)
            self.proc = subprocess.Popen(
                [sys.executable, "-m", "yt_dlp", "--quiet", "--no-warnings", "--skip-download", "--write-subs",
                 "--sub-langs", "live_chat", "-o", str(pasta / "c"),
                 f"https://www.youtube.com/watch?v={self.video_id}"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            arq = pasta / "c.live_chat.json.part"
            pos, resto = 0, b""
            while not self.parar.is_set() and self.proc.poll() is None:
                time.sleep(1)
                if not arq.exists():
                    continue
                with open(arq, "rb") as f:
                    f.seek(pos)
                    dados = f.read()
                    pos = f.tell()
                *linhas, resto = (resto + dados).split(b"\n")
                for l in linhas:
                    self._ler_linha(l)
            if self.proc.poll() is None:
                self.proc.kill()
            if not self.parar.is_set():
                log(self.canal, "chat do YouTube caiu, reconectando...")
                time.sleep(5)
        shutil.rmtree(pasta, ignore_errors=True)

    def _ler_linha(self, linha):
        try:
            obj = json.loads(linha)
        except ValueError:
            return
        acoes = obj.get("replayChatItemAction", {}).get("actions", [])
        for a in acoes:
            r = a.get("addChatItemAction", {}).get("item", {}).get("liveChatTextMessageRenderer")
            if not r:
                continue
            texto = "".join(run.get("text", "") for run in r.get("message", {}).get("runs", []))
            t = int(r.get("timestampUsec", 0)) / 1e6 or time.time()
            with self.lock:
                self.msgs.append((t, texto))

    def janela(self, inicio, fim):
        with self.lock:
            # mensagens do YouTube podem chegar fora de ordem
            limite = time.time() - 1200
            self.msgs = collections.deque(m for m in self.msgs if m[0] >= limite)
            return [txt for t, txt in self.msgs if inicio <= t < fim]


# --------------------------------------------------------------------------
# Detector de picos
# --------------------------------------------------------------------------
class Detector:
    def __init__(self, cfg, chat):
        self.cfg = cfg
        self.chat = chat
        self.inicio = time.time()
        self.ultimo_corte = 0.0
        self.palavras = [p.lower() for p in cfg["palavras_hype"]]

    def _hype(self, msgs):
        return sum(1 for m in msgs if any(p in m.lower() for p in self.palavras))

    def checar(self):
        """Retorna (tempo_do_pico, força, mensagens, motivo) ou None.

        Dispara em dois casos:
          - o chat ficou X vezes mais rápido que o normal (multiplicador_pico, padrão 2x)
          - onda de KKKK / CLIPA / POG: muitas mensagens de hype, bem acima do normal do canal
        """
        agora = time.time()
        jan = self.cfg["janela_chat_seg"]
        if agora - self.inicio < 60:  # precisa de 1 min de histórico
            return None
        if agora - self.ultimo_corte < self.cfg.get("intervalo_minimo_entre_cortes_seg", 10):
            return None

        atuais = self.chat.janela(agora - jan, agora)
        historico = self.chat.janela(agora - 300, agora - jan)
        dur_hist = max(min(300 - jan, agora - jan - self.inicio), 1)
        base = len(historico) / dur_hist * jan                   # mensagens normais por janela
        base_hype = self._hype(historico) / dur_hist * jan        # hype normal por janela

        hype = self._hype(atuais)
        score = len(atuais) * (1 + hype / max(len(atuais), 1))
        forca = round(score / max(base, 1), 1)

        if len(atuais) >= self.cfg["minimo_msgs_na_janela"] and score >= max(base, 1) * self.cfg["multiplicador_pico"]:
            self.ultimo_corte = agora
            return agora, forca, atuais, "chat acelerou"
        if hype >= self.cfg.get("minimo_hype_na_janela", 8) and hype >= max(base_hype, 1) * 2.5 \
                and hype >= 0.3 * len(atuais):
            self.ultimo_corte = agora
            return agora, forca, atuais, "onda de KKKK/CLIPA"
        return None


class DetectorAudio:
    """Escuta a voz do streamer: grito, risada alta ou mudança brusca de volume.

    Analisa cada pedaço de 60s assim que ele termina de gravar e compara o volume com o
    normal dos últimos 10 minutos daquela live.
    """

    BLOCO = 0.5  # segundos

    def __init__(self, cfg):
        self.cfg = cfg
        self.hist = collections.deque(maxlen=int(600 / self.BLOCO))
        self.ultimo_pos = -999.0

    def analisar(self, arquivo, inicio_seg):
        """Retorna lista de (posição_na_gravação, força) dos picos de voz nesse pedaço."""
        import numpy as np
        try:
            raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(arquivo), "-vn", "-ac", "1", "-ar", "8000",
                                  "-f", "s16le", "-"], capture_output=True, timeout=60).stdout
        except Exception:
            return []
        a = np.frombuffer(raw, np.int16).astype(np.float32)
        n = int(8000 * self.BLOCO)
        if len(a) < n * 4:
            return []
        rms = np.sqrt((a[: len(a) // n * n].reshape(-1, n) ** 2).mean(axis=1)) + 1
        picos = []
        if len(self.hist) >= 240:  # precisa de 2 min de referência
            # referência = o volume "alto normal" do streamer (90% do tempo ele fala mais baixo que isso);
            # só conta como grito o que passa bem disso
            normal = float(np.percentile(self.hist, 90))
            fator = self.cfg.get("fator_volume_grito", 1.6)
            alto = rms > normal * fator
            i = 0
            while i < len(alto):
                if alto[i]:
                    j = i
                    while j < len(alto) and alto[j]:
                        j += 1
                    if j - i >= 2:  # pelo menos 1s alto (evita estalo/tiro isolado)
                        k = i + int(np.argmax(rms[i:j]))
                        pos = inicio_seg + k * self.BLOCO
                        if pos - self.ultimo_pos >= 20:
                            picos.append((pos, round(float(rms[k] / normal), 1)))
                            self.ultimo_pos = pos
                    i = j
                else:
                    i += 1
        self.hist.extend(rms.tolist())
        return picos


# --------------------------------------------------------------------------
# Gravador (streamlink | ffmpeg segment)
# --------------------------------------------------------------------------
def info_live(url):
    """Retorna (ao_vivo, categoria, titulo, id_do_video)."""
    from streamlink import Streamlink
    try:
        s = Streamlink()
        _, plugin_cls, url_ok = s.resolve_url(url)
        plugin = plugin_cls(s, url_ok)
        if not plugin.streams():
            return False, None, None, None
        return True, plugin.get_category(), plugin.get_title(), plugin.get_id()
    except Exception:
        return False, None, None, None


def jogo_ok(categoria, titulo, plataforma, cfg):
    """Twitch: confere a categoria. YouTube (categoria é só 'Gaming'): confere o título."""
    filtro = cfg.get("filtro_jogo")
    if not filtro:
        return True
    if plataforma == "twitch":
        return bool(categoria) and categoria.lower() == filtro.lower()
    t = (titulo or "").lower()
    return any(p.lower() in t for p in cfg.get("palavras_titulo_youtube", ["gta 6", "gta vi", "gta6"]))


class Gravacao:
    def __init__(self, canal, url, cfg):
        self.canal = canal
        self.pasta = BASE / cfg["pasta_gravacao"] / canal / datetime.now().strftime("%Y%m%d_%H%M%S")
        self.pasta.mkdir(parents=True, exist_ok=True)
        # gravações de sessões anteriores desse canal: apaga os pedaços mais velhos que o limite
        limite = time.time() - cfg["guardar_gravacao_minutos"] * 60
        for antigo in self.pasta.parent.glob("*/seg_*.ts"):
            try:
                if antigo.stat().st_mtime < limite:
                    antigo.unlink()
            except OSError:
                pass
        self.lista = self.pasta / "segmentos.csv"
        self.sl = subprocess.Popen(
            [sys.executable, "-m", "streamlink", "--loglevel", "error", "-O", url, cfg["qualidade"]],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.ff = subprocess.Popen(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", "pipe:0", "-c", "copy", "-map", "0",
             "-f", "segment", "-segment_time", "60", "-reset_timestamps", "1",
             "-segment_list", "segmentos.csv", "-segment_list_type", "csv", "seg_%05d.ts"],
            stdin=self.sl.stdout, cwd=self.pasta, stderr=subprocess.DEVNULL)
        self.sl.stdout.close()
        self.segmentos = []        # (arquivo, inicio, fim)
        self.offset = None         # relógio - tempo_da_gravacao
        self._lidas = 0

    def ativa(self):
        return self.ff.poll() is None

    def parar(self):
        for p in (self.sl, self.ff):
            if p.poll() is None:
                p.terminate()
        try:
            self.ff.wait(10)
        except subprocess.TimeoutExpired:
            self.ff.kill()

    def atualizar(self):
        """Lê segmentos finalizados e recalibra relógio <-> tempo da gravação."""
        if not self.lista.exists():
            return
        with open(self.lista, newline="") as f:
            linhas = list(csv.reader(f))
        novas = linhas[self._lidas:]
        if not novas:
            return
        self._lidas = len(linhas)
        for nome, ini, fim in novas:
            # tempos são cumulativos a partir do início da gravação
            self.segmentos.append((nome, float(ini), float(fim)))
        # o fim do último segmento acabou de ser escrito ~agora
        self.offset = time.time() - self.segmentos[-1][2]
        # guarda "horário do relógio -> segundo da gravação" para cortes manuais por horário
        with open(self.pasta / "mapa.csv", "a", encoding="utf-8") as f:
            f.write(f"{time.time():.1f},{self.segmentos[-1][2]:.2f}\n")

    def tempo_gravado(self):
        return self.segmentos[-1][2] if self.segmentos else 0.0

    def limpar_antigos(self, manter_seg):
        limite = self.tempo_gravado() - manter_seg
        for nome, ini, fim in self.segmentos:
            if fim < limite:
                try:
                    (self.pasta / nome).unlink(missing_ok=True)
                except OSError:
                    pass


# --------------------------------------------------------------------------
# Detecção automática da câmera do streamer
# --------------------------------------------------------------------------
def detectar_facecam(video, amostras=16):
    """Acha a webcam do streamer no vídeo. Retorna [x, y, w, h] em frações (0-1) ou None.

    Ideia: a cara do streamer fica PARADA no mesmo lugar em todos os frames
    (personagens do jogo se mexem). E o fundo da webcam (o quarto) quase não muda,
    enquanto o jogo muda o tempo todo, então dá para achar a borda da câmera.
    """
    import cv2
    import numpy as np

    cap = cv2.VideoCapture(str(video))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    rosto = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    frames, faces = [], []
    for i in range(amostras):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(total * (i + 0.5) / amostras))
        ok, f = cap.read()
        if not ok:
            continue
        H, W = f.shape[:2]
        esc = 640 / W
        g = cv2.cvtColor(cv2.resize(f, (640, int(H * esc))), cv2.COLOR_BGR2GRAY)
        frames.append(g)
        for (x, y, w, h) in rosto.detectMultiScale(g, 1.1, 5, minSize=(18, 18)):
            faces.append((x, y, w, h))
    cap.release()
    if not frames or not faces:
        return None
    gh, gw = frames[0].shape

    # agrupa rostos pela posição; a webcam é o grupo que aparece em mais frames
    grupos = []
    for f in faces:
        cx, cy = f[0] + f[2] / 2, f[1] + f[3] / 2
        for gr in grupos:
            if abs(gr["cx"] - cx) < gw * 0.05 and abs(gr["cy"] - cy) < gh * 0.07:
                gr["itens"].append(f)
                break
        else:
            grupos.append({"cx": cx, "cy": cy, "itens": [f]})
    melhor = max(grupos, key=lambda g: len(g["itens"]))
    if len(melhor["itens"]) < max(3, len(frames) * 0.3):
        return None
    fx, fy, fw, fh = np.median(np.array(melhor["itens"]), axis=0)
    cx, cy = fx + fw / 2, fy + fh / 2

    # tenta achar a caixa da webcam: região que muda pouco ao redor do rosto
    caixa = None
    pilha = np.stack(frames).astype(np.float32)
    parado = (pilha.std(axis=0) < 10).astype(np.uint8)
    parado[int(fy):int(fy + fh), int(fx):int(fx + fw)] = 1
    parado = cv2.morphologyEx(parado, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, rot, stats, _ = cv2.connectedComponentsWithStats(parado)
    r = rot[int(cy), int(cx)]
    if r:
        x, y, w, h = stats[r][:4]
        if fw * 1.8 <= w <= fw * 7 and fh * 1.5 <= h <= fh * 6 and w * h < gw * gh * 0.25:
            caixa = (x, y, w, h)

    if caixa is None:
        # não achou a borda: recorta em volta do rosto
        w = fw * 3.6
        h = w / (1080 / 760)
        x, y = cx - w / 2, cy - h * 0.45
        caixa = (max(0, x), max(0, y), min(w, gw), min(h, gh))
    x, y, w, h = caixa
    x, y = min(max(0, x), gw - w), min(max(0, y), gh - h)

    # ajuste fino: procura as linhas retas da borda da webcam na imagem média
    media = pilha.mean(axis=0)
    gx = np.abs(cv2.Sobel(media, cv2.CV_32F, 1, 0, ksize=3))
    gy = np.abs(cv2.Sobel(media, cv2.CV_32F, 0, 1, ksize=3))

    def borda(grad, eixo, a, b, ini, fim, atual, externo):
        """externo='min' pega a linha forte mais à esquerda/acima, 'max' a mais à direita/abaixo
        (a borda da webcam é a linha forte mais de fora; dentro tem prateleiras etc.)."""
        a, b = int(max(0, a)), int(min(grad.shape[1 - eixo] - 1, b))
        ini, fim = int(max(0, ini)), int(min(grad.shape[eixo], fim))
        if b <= a + 2 or fim <= ini + 2:
            return atual
        if eixo == 0:   # procurando coluna (borda vertical)
            perfil = grad[ini:fim, a:b].mean(axis=0)
        else:           # procurando linha (borda horizontal)
            perfil = grad[a:b, ini:fim].mean(axis=1)
        limite = max(2.5 * np.median(perfil), 0.6 * perfil.max())
        fortes = np.where(perfil >= limite)[0]
        if perfil.max() < 2.5 * np.median(perfil) or not len(fortes):
            return atual
        return a + int(fortes.min() if externo == "min" else fortes.max())

    x0 = borda(gx, 0, x - w * .2, cx - fw * .75, y, y + h, x, "min")
    x1 = borda(gx, 0, cx + fw * .75, x + w * 1.2, y, y + h, x + w, "max")
    y0 = borda(gy, 1, y - h * .2, cy - fh * .75, x0, x1, y, "min")
    y1 = borda(gy, 1, cy + fh * .75, y + h * 1.2, x0, x1, y + h, "max")
    if x1 - x0 >= fw * 1.5 and y1 - y0 >= fh * 1.3:
        x, y, w, h = x0, y0, x1 - x0, y1 - y0
    return [round(float(v), 4) for v in (x / gw, y / gh, w / gw, h / gh)]


# --------------------------------------------------------------------------
# Legenda do post (vira o nome do arquivo)
# --------------------------------------------------------------------------
def montar_legenda(nome, palavras, pico, cfg, chat=None, grito=0.0, frames=None):
    """Gancho com a reação + frase que o streamer falou no momento + hashtags."""
    frases, atual = [], []
    for i, w in enumerate(palavras or []):
        atual.append(w)
        fim_frase = w.word.strip()[-1:] in ".!?"
        pausa = i + 1 < len(palavras) and palavras[i + 1].start - w.end > 0.6
        if fim_frase or pausa or i + 1 == len(palavras):
            frases.append(atual)
            atual = []

    def nota(f):
        n = len(f)
        if n < 3:
            return -1
        meio = (f[0].start + f[-1].end) / 2
        perto = 1 / (1 + abs(meio - (pico - 4)) / 6)   # o momento é logo antes do pico do chat
        tamanho = n if n <= 8 else max(1, 8 - (n - 8) * 0.7)   # frases curtas e diretas valem mais
        forte = 1.5 if re.search(r"[!?]|caralho|meu deus|não acredito|mano|nossa|socorro|kkk",
                                 " ".join(w.word for w in f).lower()) else 1
        return perto * tamanho * forte

    frase = ""
    if frases:
        melhor = max(frases, key=nota)
        if nota(melhor) > 0:
            frase = " ".join(w.word.strip() for w in melhor)
    frase = re.sub(r"^[,.;:\s]+|[.,;:\s]+$", "", frase).strip().upper()
    curta = frase if len(frase) <= 45 else frase[:45].rsplit(" ", 1)[0] + "..."

    # REAÇÃO: o que aconteceu no momento (chat + grito + fala)
    reacao = analisar_reacao(chat or [], palavras or [], grito)
    gancho = random.choice(GANCHOS[reacao]).format(n=nome.upper())

    # faixa vermelha: descreve a REAÇÃO -> "ALANZOKA SURTOU FUGINDO DA POLÍCIA"
    texto_todo = " ".join(w.word for w in (palavras or [])) + " " + " ".join(chat or [])
    faixa, emoji = descrever_reacao(nome, reacao, texto_todo)
    gancho = f"{faixa} {emoji}"

    # se o Claude Code estiver logado, ele escreve textos mais criativos
    ia = textos_ia(nome, palavras, chat, reacao, cfg, frames)
    if ia:
        faixa = ia.get("faixa") or faixa
        gancho = ia.get("titulo") or gancho
        curta = ""

    faixa = re.sub(r"[^\w\s,.!?'\-À-ÿ]", "", faixa).strip().upper()   # tira emoji (a fonte não tem)
    tag_nome = re.sub(r"[^a-z0-9]", "", nome.lower())
    tags = cfg.get("hashtags", ["#gta6", "#gtavi", "#cortes", "#shorts"])
    titulo = gancho + (f" “{curta}”" if curta else "") + f" #{tag_nome} " + " ".join(tags)
    return re.sub(r'[\\/:*?"<>|]', "", titulo).strip(), reacao, faixa


_IA_FALHOU_EM = [0.0]   # se falhar, tenta de novo depois de 10 min (ex.: depois de você logar)


def textos_ia(nome, palavras, chat, reacao, cfg, frames=None):
    """Claude Code olha os frames do corte + fala + chat e descreve o que REALMENTE aconteceu.
    Retorna {"faixa", "titulo"} ou None."""
    if not cfg.get("usar_ia", True) or not shutil.which("claude"):
        return None
    if time.time() - _IA_FALHOU_EM[0] < 600:
        return None
    fala = " ".join(w.word.strip() for w in (palavras or []))
    frames = [Path(f) for f in (frames or []) if Path(f).exists()]
    prompt = (
        "Você é editor de cortes de GTA 6 para TikTok/Shorts no Brasil.\n"
        f"Streamer: {nome}.\n"
        + (f"Abra e OLHE estas imagens do corte, em ordem (gameplay + câmera do streamer): "
           f"{', '.join(f.name for f in frames)}.\n" if frames else "")
        + f"Transcrição do que o streamer falou: \"{fala[:1200]}\"\n"
        f"Mensagens do chat no momento: {' | '.join((chat or [])[:40])}\n"
        f"Reação medida automaticamente (pode estar errada): {reacao}.\n\n"
        "REGRA PRINCIPAL: descreva SÓ o que dá para CONFIRMAR nas imagens, na fala ou no chat. "
        "NÃO invente situação, lugar, personagem ou ação. Se não der para saber o que aconteceu, "
        "use a reação do streamer ou uma fala real dele.\n\n"
        "Responda SÓ um JSON: {\"faixa\": \"...\", \"titulo\": \"...\"}.\n"
        f"faixa = frase curta (máx 9 palavras), CAIXA ALTA, sem emoji, começando com o nome '{nome.upper()}', "
        "dizendo o que ele fez/como reagiu, no estilo dos cortes grandes.\n"
        "titulo = legenda do post, CAIXA ALTA, 1-2 emojis, máx 70 caracteres, sem hashtags, também verdadeira.")
    try:
        r = subprocess.run(["claude", "-p", "--model", cfg.get("modelo_ia", "sonnet"),
                            "--allowedTools", "Read"],
                           input=prompt, capture_output=True, text=True, encoding="utf-8", timeout=180,
                           cwd=str(frames[0].parent) if frames else None)
        m = re.search(r"\{.*\}", r.stdout, re.S)
        if r.returncode != 0 or not m:
            raise RuntimeError((r.stdout + r.stderr).strip()[:150])
        return json.loads(m.group(0))
    except Exception as e:
        _IA_FALHOU_EM[0] = time.time()
        log("ia", f"Claude Code indisponível ({e}) - faixa sem IA; tento de novo em 10 min")
        return None


def extrair_frames(video, pasta, nome, quantos=4, pico=None):
    """Tira alguns frames do corte (concentrados perto do pico do chat) para a IA olhar."""
    import cv2
    cap = cv2.VideoCapture(str(video))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    dur = (cap.get(cv2.CAP_PROP_FRAME_COUNT) or 1) / fps
    centro = pico if pico else dur / 2
    tempos = [max(0.5, min(dur - 0.5, centro + d)) for d in (-14, -8, -3, 2)][:quantos]
    saida = []
    for i, t in enumerate(tempos):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, f = cap.read()
        if ok:
            p = pasta / f"_{nome}_frame{i + 1}.jpg"
            h, w = f.shape[:2]
            cv2.imwrite(str(p), cv2.resize(f, (960, int(h * 960 / w))), [cv2.IMWRITE_JPEG_QUALITY, 80])
            saida.append(p)
    cap.release()
    return saida


def desenhar_faixa(texto, destino, largura=1080):
    """Desenha a faixa vermelha estilo 'papel rasgado' com o texto branco. Retorna a altura."""
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
    fonte_arq = next((f for f in (r"C:\Windows\Fonts\ariblk.ttf", r"C:\Windows\Fonts\impact.ttf",
                                  r"C:\Windows\Fonts\arialbd.ttf") if os.path.exists(f)), None)
    util = largura - 140

    def quebrar(tam):
        fonte = ImageFont.truetype(fonte_arq, tam) if fonte_arq else ImageFont.load_default()
        linhas, atual = [], ""
        for p in texto.split():
            t = (atual + " " + p).strip()
            if fonte.getlength(t) <= util:
                atual = t
            else:
                if atual:
                    linhas.append(atual)
                atual = p
        linhas.append(atual)
        return fonte, linhas

    for tam in range(74, 40, -4):                       # maior fonte que caiba em 3 linhas
        fonte, linhas = quebrar(tam)
        if len(linhas) <= 3 and all(fonte.getlength(l) <= util for l in linhas):
            break
    alt_linha = int(tam * 1.18)
    altura = alt_linha * len(linhas) + 70
    img = Image.new("RGBA", (largura, altura + 20), (0, 0, 0, 0))

    # borda rasgada: pontos irregulares em cima e embaixo
    rnd = random.Random(texto)
    cima = [(x, 14 + rnd.randint(-10, 10)) for x in range(18, largura - 17, 22)]
    baixo = [(x, altura - 4 + rnd.randint(-10, 10)) for x in range(largura - 18, 17, -22)]
    forma = [(8, 22)] + cima + [(largura - 8, 18), (largura - 2, altura // 2), (largura - 10, altura - 2)] \
        + baixo + [(10, altura), (2, altura // 2)]

    sombra = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(sombra).polygon([(x + 6, y + 8) for x, y in forma], fill=(0, 0, 0, 150))
    img = Image.alpha_composite(img, sombra.filter(ImageFilter.GaussianBlur(6)))
    d = ImageDraw.Draw(img)
    d.polygon(forma, fill=(214, 20, 28, 255))
    # textura leve de papel
    for _ in range(900):
        x, y = rnd.randint(0, largura - 1), rnd.randint(10, altura - 10)
        if img.getpixel((x, y))[3]:
            d.point((x, y), fill=(190, 12, 20, 255) if rnd.random() < .5 else (232, 40, 46, 255))

    y = (altura + 10 - alt_linha * len(linhas)) // 2
    for l in linhas:
        w = fonte.getlength(l)
        d.text(((largura - w) / 2, y), l, font=fonte, fill="white", stroke_width=6, stroke_fill="black")
        y += alt_linha
    img.save(destino)
    return img.height


# frases de gancho por tipo de reação ({n} = nome do streamer)
GANCHOS = {
    "risada":  ["{n} NÃO AGUENTOU DE RIR 😂", "{n} CHOROU DE RIR COM ISSO 😂🤣", "O CHAT MORREU DE RIR COM O {n} 😂",
                "{n} PERDEU O AR DE TANTO RIR 🤣"],
    "grito":   ["{n} SURTOU NO GTA 6 😱🔥", "{n} GRITOU MUITO COM ISSO 😱", "{n} PERDEU A CABEÇA 🤯",
                "OLHA A REAÇÃO DO {n} 😱"],
    "susto":   ["{n} TOMOU O MAIOR SUSTO 😨", "{n} QUASE CAIU DA CADEIRA 😱", "{n} SE ASSUSTOU FEIO NO GTA 6 😨"],
    "falha":   ["{n} PASSOU VERGONHA NO GTA 6 💀", "DEU TUDO ERRADO PRO {n} 💀😂", "{n} NÃO ACREDITOU NO QUE FEZ 💀",
                "O {n} SE LASCOU 💀"],
    "choque":  ["{n} NÃO ACREDITOU NO QUE VIU 😳", "{n} FICOU SEM REAÇÃO 😳", "O {n} FICOU CHOCADO 😳🤯"],
    "hype":    ["{n} FEZ O IMPOSSÍVEL NO GTA 6 🔥", "JOGADA INSANA DO {n} 🔥😱", "O CHAT ENLOUQUECEU COM O {n} 🔥",
                "{n} AMASSOU NO GTA 6 🔥🔥"],
    "raiva":   ["{n} FICOU PISTOLA NO GTA 6 😡", "{n} PERDEU A PACIÊNCIA 😡🤬", "O GTA 6 TIROU O {n} DO SÉRIO 😡"],
    "neutro":  ["OLHA O QUE ACONTECEU COM O {n} 😳", "{n} VIVEU ISSO NO GTA 6 👀", "ISSO SÓ ACONTECE COM O {n} 😂"],
}

# o que o streamer fez, por reação: (frase, emoji)
ACOES = {
    "risada": [("NÃO AGUENTOU DE RIR", "😂"), ("CHOROU DE RIR", "🤣"), ("MORREU DE RIR", "😂")],
    "grito":  [("SURTOU", "😱"), ("PERDEU A CABEÇA", "🤯"), ("GRITOU DESESPERADO", "😱")],
    "susto":  [("TOMOU O MAIOR SUSTO", "😨"), ("QUASE CAIU DA CADEIRA", "😱"), ("SE ASSUSTOU FEIO", "😨")],
    "falha":  [("PASSOU VERGONHA", "💀"), ("SE LASCOU", "💀"), ("FEZ A MAIOR BURRADA", "💀")],
    "choque": [("NÃO ACREDITOU", "😳"), ("FICOU SEM REAÇÃO", "😳"), ("FICOU CHOCADO", "🤯")],
    "hype":   [("FEZ O IMPOSSÍVEL", "🔥"), ("AMASSOU", "🔥"), ("DEU AULA", "🔥")],
    "raiva":  [("FICOU PISTOLA", "😡"), ("PERDEU A PACIÊNCIA", "🤬"), ("RAGEOU", "😡")],
    "neutro": [("VIVEU ISSO", "👀"), ("NÃO ESPERAVA POR ISSO", "😳")],
}

# onde/o quê no GTA 6, pelas palavras da fala + chat
CONTEXTOS = [
    (r"pol[ií]cia|viatura|procurad|estrela|sirene|cop", "FUGINDO DA POLÍCIA"),
    (r"assalt|roub|banco|caixa|cofre", "NO ASSALTO"),
    (r"tiro|arma|atir|bala|matei|metralha|pistola\b|fuzil", "NO TIROTEIO"),
    (r"jacar[eé]|crocodil|aligator", "COM UM JACARÉ"),
    (r"barco|lancha|\bmar\b|navio|nadar|[aá]gua", "NO MEIO DO MAR"),
    (r"avi[aã]o|helic[oó]pter|voando|paraquedas", "VOANDO NO GTA 6"),
    (r"\bmoto\b|motoca|grau", "DE MOTO"),
    (r"bati|batida|capot|acident|atropel", "BATENDO O CARRO"),
    (r"carro|seta|dirig|volante|acelera|pista|corrida|tr[aâ]nsito", "NO VOLANTE"),
    (r"lucia|l[uú]cia", "COM A LUCIA"),
    (r"jason", "COM O JASON"),
    (r"morr|morte|morreu", "E MORREU"),
    (r"bug|glitch|travou|bugou", "COM UM BUG"),
    (r"praia|vice city|miami|leonida", "EM VICE CITY"),
    (r"mulher|namorad|beij|date", "NO DATE"),
]


def descrever_reacao(nome, reacao, texto):
    """Sem IA: só o que foi medido (reação do chat/voz) + 'NO GTA 6'. Não inventa o que aconteceu.
    Retorna (faixa, emoji)."""
    contexto = "NO GTA 6"
    acao, emoji = random.choice(ACOES.get(reacao, ACOES["neutro"]))
    return f"{nome.upper()} {acao} {contexto}", emoji


SINAIS = {
    "risada": (r"k{3,}|ksks|haha|rsrs|kek|lul|lol|omegalul|😂|🤣|lmao|icant", r"k{3,}|haha|rsrs"),
    "falha":  (r"^f$|\brip\b|💀|morreu|morre|perdeu|noob|burro|errou|vergonha|fail|kekw", r"morri|errei|merda|droga|perdi|ferrou|lasc"),
    "susto":  (r"susto|assust|jumpscare|medo|😨|😱", r"susto|assust|medo|socorro|caramba|que isso"),
    "choque": (r"^\?+$|\?\?|wtf|oq|o que|que\?|nani|😳|🤯", r"não acredito|como assim|o que|mano do céu|meu deus|nossa"),
    "hype":   (r"pog|insano|monstro|absurdo|brabo|gigante|🔥|clipa|clip|god|goat|jogou muito", r"vamo|bora|consegui|isso|toma|ganhei|lindo"),
    "raiva":  (r"pistola|tilt|raiva|calma|😡|🤬|chorou", r"porra|caralho|vai se|cacete|desgraça|ódio|lixo"),
}


def analisar_reacao(chat, palavras, grito):
    """Decide qual foi a reação do momento: risada, grito, susto, falha, choque, hype, raiva."""
    fala = " ".join(w.word.strip().lower() for w in palavras)
    pontos = {k: 0.0 for k in SINAIS}
    for msg in chat:
        m = msg.lower().strip()
        for k, (re_chat, _) in SINAIS.items():
            if re.search(re_chat, m):
                pontos[k] += 1
    total = max(len(chat), 1)
    for k in pontos:
        pontos[k] = pontos[k] / total * 10           # % do chat reagindo daquele jeito
        pontos[k] += 2 * len(re.findall(SINAIS[k][1], fala))
    if grito >= 9:                                     # pico de volume muito acima da fala normal = gritou
        pontos["susto"] += 1.5
        pontos["grito"] = grito - 6
    melhor = max(pontos, key=pontos.get)
    return melhor if pontos[melhor] >= 2 else ("grito" if grito >= 9 else "neutro")


def medir_grito(video):
    """Quanto o som mais alto do corte passa do volume normal (3+ = grito)."""
    import numpy as np
    try:
        raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(video), "-ac", "1", "-ar", "8000",
                              "-f", "s16le", "-"], capture_output=True, check=True).stdout
        a = np.frombuffer(raw, np.int16).astype(np.float32)
        blocos = a[: len(a) // 4000 * 4000].reshape(-1, 4000)       # pedaços de 0,5s
        rms = np.sqrt((blocos ** 2).mean(axis=1)) + 1
        return float(np.percentile(rms, 98) / np.median(rms))
    except Exception:
        return 0.0


def nome_livre(pasta, base):
    """Nome de arquivo válido no Windows, sem sobrescrever outro corte."""
    limite = min(130, 245 - len(str(pasta)) - 10)   # Windows não aceita caminho com +260 letras
    base = base[:max(limite, 20)].rstrip(" .")
    destino = pasta / f"{base}.mp4"
    n = 2
    while destino.exists():
        destino = pasta / f"{base} ({n}).mp4"
        n += 1
    return destino


# --------------------------------------------------------------------------
# Editor (corte + vertical + legenda)
# --------------------------------------------------------------------------
class Editor(threading.Thread):
    """Uma fila única de edição para não sobrecarregar a GPU."""

    def __init__(self, cfg):
        super().__init__(daemon=True)
        self.cfg = cfg
        self.fila = queue.Queue()
        self.whisper = None
        self.whisper_disp = None
        self.cams = {}  # última posição de câmera achada por canal
        self.encoder = self._escolher_encoder()

    def _escolher_encoder(self):
        enc = self.cfg.get("encoder", "auto")
        if enc != "auto":
            return enc
        r = subprocess.run(["ffmpeg", "-hide_banner", "-f", "lavfi", "-i", "testsrc=s=320x240:d=0.5",
                            "-c:v", "h264_nvenc", "-f", "null", "-"], capture_output=True)
        return "h264_nvenc" if r.returncode == 0 else "libx264"

    def _args_video(self):
        if self.encoder == "h264_nvenc":
            return ["-c:v", "h264_nvenc", "-preset", "p5", "-cq", "21", "-b:v", "0"]
        return ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20"]

    def run(self):
        while True:
            job = self.fila.get()
            nome = job.get("nome_bonito") or job.get("canal", "?")
            bloco = job.get("tipo") == "bloco"
            status_editor(f"IA analisando 10 min de {nome}" if bloco else f"cortando um momento de {nome}",
                          self.fila.qsize())
            try:
                if job.pop("tipo", None) == "bloco":
                    self.processar_bloco(**job)
                else:
                    self.processar(**job)
            except Exception as e:
                log(job.get("canal", "?"), f"erro ao editar: {e}")
                status_canal(job.get("canal", "?"), ia_etapa="")
            status_editor("", self.fila.qsize())

    def _modelo_whisper(self):
        from faster_whisper import WhisperModel
        if self.whisper is None:
            try:
                self.whisper = WhisperModel(self.cfg["modelo_whisper"], device="cuda", compute_type="float16")
                self.whisper_disp = "cuda"
            except Exception:
                self.whisper = WhisperModel(self.cfg["modelo_whisper"], device="cpu", compute_type="int8")
                self.whisper_disp = "cpu"
        return self.whisper

    def processar_bloco(self, canal, segs, bloco_ini, bloco_fim, chat, layout="auto", facecam=None, nome_bonito=None,
                        url=None):
        """Modo IA (estilo Cut.Pro): transcreve o bloco, a IA escolhe os melhores momentos e já sai pronto.
        segs: [(arquivo, inicio_seg, fim_seg)] em tempo da gravação; chat: [(seg_no_bloco, msg)]."""
        import ia_cortes
        import importlib
        importlib.reload(ia_cortes)  # pega ajustes nas regras da IA sem reiniciar o app
        cfg_ia = ia_cortes.carregar()
        nome = nome_bonito or canal
        duracao = bloco_fim - bloco_ini
        segs = [(Path(a), i, f) for a, i, f in segs if Path(a).exists()]
        if not segs:
            return
        log(canal, f"IA: analisando bloco de {duracao / 60:.0f} min ({len(chat)} msgs no chat)…")
        status_canal(canal, ia_etapa="transcrevendo a fala dos últimos minutos…")
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            lista = tmp / "lista.txt"
            lista.write_text("".join(f"file '{a.as_posix()}'\n" for a, _, _ in segs), encoding="utf-8")
            wav = tmp / "bloco.wav"
            subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
                            "-i", str(lista), "-ss", f"{max(0.0, bloco_ini - segs[0][1]):.2f}", "-t", f"{duracao:.2f}",
                            "-vn", "-ac", "1", "-ar", "16000", str(wav)], check=True)
            try:
                # idioma detectado frase a frase: a fala do jogo (inglês) NÃO é traduzida como se fosse do streamer
                partes, _ = self._modelo_whisper().transcribe(str(wav), language=None, multilingual=True,
                                                               vad_filter=True)
                import ia_cortes
                transcricao = [(x.start, x.end, ("[JOGO] " if ia_cortes.fala_do_jogo(x.text) else "") + x.text.strip())
                               for x in partes]
            except Exception as e:
                self.whisper = None
                self.whisper_disp = None
                log(canal, f"IA: não consegui transcrever o bloco ({e})")
                status_canal(canal, ia_etapa="", ia_ultimo=f"{datetime.now():%H:%M} erro ao transcrever")
                return
        status_canal(canal, ia_etapa="a IA está lendo a fala e o chat e escolhendo os melhores momentos…")
        try:
            momentos = ia_cortes.escolher_momentos(nome, transcricao, chat, duracao,
                                                   cfg_ia["nota_minima"], cfg_ia["max_por_bloco"])
        except ia_cortes.ErroIA as e:
            log(canal, f"IA: {e}")
            status_canal(canal, ia_etapa="", ia_ultimo=f"{datetime.now():%H:%M} erro da IA: {e}")
            return
        if not momentos:
            log(canal, f"IA: nada bom nesse bloco (nota mínima {cfg_ia['nota_minima']})")
            status_canal(canal, ia_etapa="", ia_ultimo=f"{datetime.now():%H:%M} analisou {duracao / 60:.0f} min: "
                                                      f"nenhum momento com nota {cfg_ia['nota_minima']}+")
            return
        status_canal(canal, ia_ultimo=f"{datetime.now():%H:%M} analisou {duracao / 60:.0f} min: "
                                      f"achou {len(momentos)} momento(s) bom(ns)")
        for n, m in enumerate(momentos, 1):
            status_canal(canal, ia_etapa=f"editando corte {n} de {len(momentos)}: {m['faixa']}")
            ini, fim = bloco_ini + m["inicio"], bloco_ini + m["fim"]
            usados = [(a, i, f) for a, i, f in segs if f > ini and i < fim and a.exists()]
            if not usados:
                continue
            log(canal, f"IA: nota {m['nota']:.0f} - {m['faixa']} ({m['motivo']})")
            jp = self.processar(canal, [a for a, _, _ in usados], ini - usados[0][1], fim - ini, layout, facecam,
                                {"canal": canal, "url": url, "motivos": [f"IA nota {m['nota']:.0f}: {m['motivo']}"],
                                 "horario": datetime.now().isoformat(timespec="seconds"),
                                 "chat_no_momento": [t for x, t in chat if m["inicio"] <= x <= m["fim"]][-40:]},
                                nome_bonito)
            if jp:
                editar_corte(self.cfg, self, jp, m["faixa"], m["titulo"],
                             {"ia_nota": m["nota"], "ia_motivo": m["motivo"]})
        status_canal(canal, ia_etapa="")

    def processar(self, canal, entradas, inicio, duracao, layout="auto", facecam=None, info=None, nome_bonito=None):
        self._ultimas_palavras = []
        # uma pasta por streamer: cortes\<Streamer>\<data>\(rascunhos | prontos | _dados)
        saida_dir = BASE / self.cfg["pasta_saida"] / pasta_do_canal(nome_bonito or canal) / datetime.now().strftime("%Y-%m-%d")
        saida_dir.mkdir(parents=True, exist_ok=True)
        nome = f"{canal}_{datetime.now():%H%M%S}"
        tmp = saida_dir / f"_{nome}_bruto.mp4"

        # 1) corta o trecho bruto
        if len(entradas) == 1:
            entrada = ["-i", str(entradas[0])]
        else:
            lista = saida_dir / f"_{nome}.txt"
            lista.write_text("".join(f"file '{Path(p).as_posix()}'\n" for p in entradas), encoding="utf-8")
            entrada = ["-f", "concat", "-safe", "0", "-i", str(lista)]
        # -ss DEPOIS do -i: decodifica e corta vídeo e áudio exatamente no mesmo instante
        # (com -ss antes, o vídeo começava atrasado em relação ao áudio = boca fora de sincronia)
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                        *entrada, "-ss", f"{inicio:.2f}", "-t", f"{duracao:.2f}",
                        "-af", "aresample=async=1", *self._args_video(), "-c:a", "aac", "-b:a", "160k", str(tmp)], check=True)
        if len(entradas) > 1:
            lista.unlink(missing_ok=True)

        # 2) legendas
        ass = None
        if self.cfg.get("legendas", True):
            ass = saida_dir / f"_{nome}.ass"
            if not self._gerar_legenda(tmp, ass):
                ass = None

        # 3) vertical 9:16 - acha a câmera do streamer sozinho
        if layout == "auto" and not facecam:
            try:
                achada = detectar_facecam(tmp)
            except Exception as e:
                achada = None
                log(canal, f"erro ao detectar câmera: {e}")
            if achada:
                self.cams[canal] = achada
            facecam = self.cams.get(canal)
            log(canal, f"câmera: {facecam if facecam else 'não encontrada (gameplay em tela cheia)'}")
        # 4) sinais da reação (para quem for escrever a faixa)
        grito = medir_grito(tmp)
        chat = (info or {}).get("chat_no_momento") or []
        reacao = analisar_reacao(chat, self._ultimas_palavras, grito)

        # 5) guarda tudo em _dados/ e gera o RASCUNHO (sem faixa); a faixa e o título
        #    são colocados depois, vendo o corte, com:  python cortes.py --editar <json> --faixa "..." --titulo "..."
        dados = saida_dir / "_dados"
        dados.mkdir(exist_ok=True)
        bruto = dados / f"{nome}_bruto.mp4"
        tmp.replace(bruto)
        ass_final = None
        if ass:
            ass_final = dados / f"{nome}.ass"
            ass.replace(ass_final)
        meta = dict(info or {})
        meta.update({
            "nome": nome, "canal": canal, "nome_bonito": nome_bonito or canal,
            "layout": layout, "facecam": facecam, "pico_no_corte_seg": min(self.cfg["segundos_antes"], duracao),
            "bruto": bruto.name, "ass": ass_final.name if ass_final else None,
            "reacao_automatica": reacao, "grito": round(grito, 1),
            "fala": [{"t": round(w.start, 1), "p": w.word.strip()} for w in self._ultimas_palavras],
            "fala_texto": " ".join(w.word.strip() for w in self._ultimas_palavras),
            "status": "rascunho",
        })
        json_path = dados / f"{nome}.json"
        rascunho = saida_dir / "rascunhos" / f"{nome}.mp4"
        rascunho.parent.mkdir(exist_ok=True)
        self.renderizar(meta, dados, rascunho, faixa=None, legendas=False)   # só o corte, sem legenda/faixa
        meta["rascunho"] = str(rascunho.relative_to(BASE))
        json_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        log(canal, f"CORTE PRONTO -> {rascunho.relative_to(BASE)}  (sem legenda e sem card - edição é feita depois)")
        if not any(str(x).startswith("IA nota") for x in meta.get("motivos", [])):
            contar_corte(canal, "rascunho", ", ".join(meta.get("motivos", [])[:2]) or "pico")
        return json_path

    def renderizar(self, meta, dados, destino, faixa=None, legendas=True):
        """Monta o vídeo final: layout + (faixa vermelha) + legenda das falas, a partir do bruto."""
        layout, facecam = meta.get("layout", "auto"), meta.get("facecam")
        com_cam = layout in ("facecam", "auto") and bool(facecam)
        png = dados / f"_{meta['nome']}_faixa.png"
        filtro = self._filtro(layout, facecam) + "[base]"
        entradas_ff = ["-i", meta["bruto"]]
        ultimo = "[base]"
        if faixa:
            altura = desenhar_faixa(faixa, png)
            y_faixa = (760 if com_cam else 1250) - altura // 2
            entradas_ff += ["-loop", "1", "-i", png.name]
            filtro += f";{ultimo}[1:v]overlay=0:{y_faixa}:shortest=1[comfaixa]"
            ultimo = "[comfaixa]"
        if legendas and meta.get("ass"):
            filtro += f";{ultimo}ass={meta['ass']}[saida]"
            ultimo = "[saida]"
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *entradas_ff,
                        "-filter_complex", filtro, "-map", ultimo, "-map", "0:a?",
                        *self._args_video(), "-c:a", "aac", "-b:a", "160k",
                        "-movflags", "+faststart", str(destino)], check=True, cwd=dados)
        png.unlink(missing_ok=True)

    @staticmethod
    def _filtro(layout, facecam):
        if layout in ("facecam", "auto") and facecam:
            # câmera do streamer em cima (760px), gameplay embaixo (1160px)
            x, y, w, h = facecam
            return (f"[0:v]split[a][b];"
                    f"[a]crop=iw*{w}:ih*{h}:iw*{x}:ih*{y},scale=1080:760:force_original_aspect_ratio=increase,crop=1080:760[cam];"
                    f"[b]crop=ih*1080/1160:ih,scale=1080:1160[jogo];"
                    f"[cam][jogo]vstack,setsar=1")
        if layout == "auto":
            # não achou câmera: gameplay em tela cheia vertical
            return "[0:v]crop=ih*9/16:ih,scale=1080:1920,setsar=1"
        # padrão: fundo desfocado + jogo inteiro no meio
        return ("[0:v]split[a][b];"
                "[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:5[fundo];"
                "[b]scale=1080:-2[jogo];"
                "[fundo][jogo]overlay=(W-w)/2:(H-h)/2,setsar=1")

    def _gerar_legenda(self, video, ass_path):
        from faster_whisper import WhisperModel
        palavras = None
        for dispositivo, tipo in (("cuda", "float16"), ("cpu", "int8")):
            if self.whisper is not None and self.whisper_disp != dispositivo:
                continue
            try:
                if self.whisper is None:
                    self.whisper = WhisperModel(self.cfg["modelo_whisper"], device=dispositivo, compute_type=tipo)
                    self.whisper_disp = dispositivo
                segs, _ = self.whisper.transcribe(str(video), language=self.cfg.get("idioma") or None,
                                                  word_timestamps=True, vad_filter=True)
                palavras = [w for s in segs for w in (s.words or [])]
                break
            except Exception as e:
                log("legenda", f"whisper falhou em {dispositivo} ({e}), tentando CPU")
                self.whisper = None
                self.whisper_disp = None
        if not palavras:
            return False
        self._ultimas_palavras = palavras

        def ts(t):
            return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"

        linhas = []
        for i in range(0, len(palavras), 3):  # 3 palavras por vez, estilo shorts
            grupo = palavras[i:i + 3]
            texto = " ".join(w.word.strip() for w in grupo).upper().replace("{", "").replace("}", "")
            linhas.append(f"Dialogue: 0,{ts(grupo[0].start)},{ts(grupo[-1].end + 0.05)},Padrao,,0,0,0,,{texto}")

        cab = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Padrao,Arial Black,72,&H0000FFFF,&H0000FFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,6,2,2,60,60,1290,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
        ass_path.write_text(cab + "\n".join(linhas) + "\n", encoding="utf-8")
        return True


# --------------------------------------------------------------------------
# Um trabalhador por canal
# --------------------------------------------------------------------------
class Canal(threading.Thread):
    def __init__(self, canal_cfg, cfg, editor):
        super().__init__(daemon=True)
        if canal_cfg.get("youtube"):
            self.plataforma = "youtube"
            handle = canal_cfg["youtube"].strip().lstrip("@")
            self.nome = "yt_" + handle.lower()
            self.url = f"https://www.youtube.com/@{handle}/live"
        else:
            self.plataforma = "twitch"
            self.nome = canal_cfg["twitch"].lower()
            self.url = f"https://www.twitch.tv/{self.nome}"
        self.ccfg = canal_cfg
        self.cfg = cfg
        self.editor = editor
        self.parar = threading.Event()  # desligar o "Monitorar" no site

    def run(self):
        aviso = None
        st = dict(plataforma=self.plataforma, nome_bonito=self.ccfg.get("nome") or self.nome)
        status_canal(self.nome, status="verificando…", monitorando=True, ativo=True, **st)
        while not self.parar.is_set():
            vivo, cat, titulo, vid = info_live(self.url)
            if self.parar.is_set():
                break
            if vivo and jogo_ok(cat, titulo, self.plataforma, self.cfg):
                log(self.nome, f"AO VIVO ({cat}: {titulo}) - gravando e lendo o chat")
                status_canal(self.nome, status="gravando", titulo=titulo, **st)
                aviso = None
                try:
                    self.sessao(vid)
                except Exception as e:
                    log(self.nome, f"erro na sessão: {e}")
                log(self.nome, "parou de gravar (live acabou ou trocou de jogo)")
                status_canal(self.nome, status="parou de gravar", titulo="", **st)
            elif vivo:
                status_canal(self.nome, status=f"ao vivo, mas não está no GTA 6 ({titulo or cat})", **st)
                if aviso != (cat, titulo):
                    log(self.nome, f"ao vivo, mas não é GTA 6 ({cat}: {titulo}) - aguardando")
                    aviso = (cat, titulo)
            else:
                status_canal(self.nome, status="offline — esperando ficar ao vivo", titulo="", **st)
            self.parar.wait(self.cfg["checar_live_a_cada_seg"])
        status_canal(self.nome, titulo="", monitorando=False)
        log(self.nome, "monitoramento desligado")

    def sessao(self, video_id=None):
        if self.plataforma == "youtube":
            chat = ChatYouTube(self.nome, video_id)
            url_grav = f"https://www.youtube.com/watch?v={video_id}"
        else:
            chat = ChatTwitch(self.nome)
            url_grav = self.url
        chat.start()
        grav = Gravacao(self.nome, url_grav, self.cfg)
        det = Detector(self.cfg, chat)
        audio = DetectorAudio(self.cfg) if self.cfg.get("detectar_voz", True) else None
        analisados = 0
        pendentes = []  # cortes esperando os segmentos ficarem prontos
        ultima_checagem = time.time()
        import ia_cortes
        bloco_ini = 0.0  # modo IA: a cada X minutos de gravação a IA escolhe os melhores momentos
        try:
            while grav.ativa() or pendentes:
                time.sleep(2)
                grav.atualizar()
                ia_on = ia_cortes.pronta()
                tam = ia_cortes.carregar()["bloco_min"] * 60
                agora = time.time()
                status_canal(self.nome, gravado_seg=round(grav.tempo_gravado()), gravando=grav.ativa(),
                             chat_min=len(chat.janela(agora - 60, agora)), momentos_esperando=len(pendentes),
                             ia_ligada=ia_on, ia_bloco_min=tam // 60,
                             ia_proximo_em=round(max(0.0, bloco_ini + tam - grav.tempo_gravado())) if ia_on else None)
                if ia_on and grav.offset is not None:
                    gravado = grav.tempo_gravado()
                    if gravado >= bloco_ini + tam or (not grav.ativa() and gravado - bloco_ini >= 180):
                        bloco_fim = min(gravado, bloco_ini + tam)
                        self.enviar_bloco(grav, chat, bloco_ini, bloco_fim)
                        status_canal(self.nome, ia_etapa="na fila para a IA analisar…")
                        bloco_ini = bloco_fim
                if self.parar.is_set() and grav.ativa():
                    log(self.nome, "monitoramento desligado no site - parando a gravação")
                    grav.parar()
                # VOZ: analisa cada pedaço novo assim que fecha
                while audio and analisados < len(grav.segmentos):
                    nome_seg, ini_seg, _ = grav.segmentos[analisados]
                    analisados += 1
                    for pos, forca in audio.analisar(grav.pasta / nome_seg, ini_seg):
                        ini = max(0.0, pos - self.cfg.get("segundos_antes_voz", 25))
                        fim = pos + self.cfg.get("segundos_depois_voz", 10)
                        log(self.nome, f"PICO de VOZ (x{forca}) - {ini:.0f}s a {fim:.0f}s")
                        self.adicionar(pendentes, {"ini": ini, "fim": fim, "forca": forca, "msgs": [],
                                                   "motivos": [f"voz x{forca}"]})
                # streamer trocou de jogo? encerra a gravação
                if grav.ativa() and time.time() - ultima_checagem > self.cfg["checar_live_a_cada_seg"]:
                    ultima_checagem = time.time()
                    vivo, cat, titulo, _ = info_live(self.url)
                    if vivo and not jogo_ok(cat, titulo, self.plataforma, self.cfg):
                        log(self.nome, f"trocou de jogo ({cat}: {titulo}) - parando")
                        grav.parar()
                if grav.ativa():
                    pico = det.checar()
                    if pico and grav.offset is not None:
                        t, forca, msgs, motivo = pico
                        pos = t - grav.offset  # posição na gravação
                        ini = max(0.0, pos - self.cfg["segundos_antes"])
                        fim = pos + self.cfg["segundos_depois"]
                        log(self.nome, f"PICO no chat - {motivo} (x{forca}) - {ini:.0f}s a {fim:.0f}s")
                        self.adicionar(pendentes, {"ini": ini, "fim": fim, "forca": forca, "msgs": msgs[-40:],
                                                   "motivos": [f"{motivo} x{forca}"]})
                elif not grav.ativa():
                    # gravação acabou: o que ficou além do fim é cortado até onde der
                    for p in pendentes:
                        p["fim"] = min(p["fim"], grav.tempo_gravado())
                prontos = [p for p in pendentes if grav.tempo_gravado() >= p["fim"]]
                for p in prontos:
                    pendentes.remove(p)
                    self.enviar(grav, p)
                grav.limpar_antigos(self.cfg["guardar_gravacao_minutos"] * 60)
        finally:
            chat.parar.set()
            grav.parar()
            status_canal(self.nome, gravando=False, ia_proximo_em=None, chat_min=0, momentos_esperando=0)

    def adicionar(self, pendentes, novo):
        """Junta momentos seguidos num corte só (em vez de perder o segundo)."""
        juntar = self.cfg.get("juntar_momentos_ate_seg", 15)
        maximo = self.cfg.get("duracao_maxima_corte_seg", 90)
        for p in pendentes:
            ini, fim = min(p["ini"], novo["ini"]), max(p["fim"], novo["fim"])
            encosta = novo["ini"] <= p["fim"] + juntar and novo["fim"] >= p["ini"] - juntar
            if encosta and fim - ini <= maximo:
                p["ini"], p["fim"] = ini, fim
                p["forca"] = max(p["forca"] or 0, novo["forca"] or 0)
                p["msgs"] = (p["msgs"] + novo["msgs"])[-60:]
                p["motivos"] = p.get("motivos", []) + novo.get("motivos", [])
                log(self.nome, f"juntou com o corte anterior -> {ini:.0f}s a {fim:.0f}s ({fim - ini:.0f}s)")
                return
        pendentes.append(novo)

    def enviar_bloco(self, grav, chat, ini, fim):
        segs = [(str(grav.pasta / n), i, f) for n, i, f in grav.segmentos if f > ini and i < fim]
        if not segs:
            return
        msgs = [(t - grav.offset - ini, txt) for t, txt in chat.com_tempo(grav.offset + ini, grav.offset + fim)]
        self.editor.fila.put({
            "tipo": "bloco", "canal": self.nome, "segs": segs, "bloco_ini": ini, "bloco_fim": fim, "chat": msgs,
            "layout": self.ccfg.get("layout", "auto"), "facecam": self.ccfg.get("facecam"), "url": self.url,
            "nome_bonito": self.ccfg.get("nome") or self.nome.removeprefix("yt_"),
        })

    def enviar(self, grav, p):
        usados = [(n, i, f) for n, i, f in grav.segmentos if f > p["ini"] and i < p["fim"]]
        usados = [(n, i, f) for n, i, f in usados if (grav.pasta / n).exists()]
        if not usados or p["fim"] - p["ini"] < 3:
            return
        self.editor.fila.put({
            "canal": self.nome,
            "entradas": [grav.pasta / n for n, _, _ in usados],
            "inicio": p["ini"] - usados[0][1],
            "duracao": p["fim"] - p["ini"],
            "layout": self.ccfg.get("layout", "auto"),
            "nome_bonito": self.ccfg.get("nome") or self.nome.removeprefix("yt_"),
            "facecam": self.ccfg.get("facecam"),
            "info": {"canal": self.nome, "url": self.url, "forca_do_pico": p["forca"],
                     "motivos": p.get("motivos", []),
                     "horario": datetime.now().isoformat(timespec="seconds"),
                     "chat_no_momento": p["msgs"]},
        })


def pasta_do_canal(nome):
    """Nome de pasta válido no Windows para o streamer (ex.: 'Paulinho o Loko')."""
    nome = re.sub(r'[\\/:*?"<>|]', "", str(nome or "outros")).strip(" .")
    return nome or "outros"


def chave_canal(c):
    return ("yt_" + c["youtube"].strip().lstrip("@").lower()) if c.get("youtube") else c.get("twitch", "").lower()


class Gerenciador:
    """Liga/desliga o monitoramento de cada canal com o app rodando (botão Monitorar do site)."""

    def __init__(self, cfg, editor):
        self.cfg = cfg
        self.editor = editor
        self.rodando = {}  # chave -> Canal
        self.lock = threading.Lock()

    def quantos(self):
        return sum(1 for t in self.rodando.values() if t.is_alive() and not t.parar.is_set())

    def ligado(self):
        """Botão geral Ligar/Parar cortador do site."""
        return self.cfg.get("cortador_ligado", True)

    def aplicar(self):
        with self.lock:
            try:
                import painel
                todas = {chave_canal(c) for c in self.cfg["canais"]}
                for k in list(painel.CANAIS):
                    if k not in todas:
                        painel.CANAIS.pop(k, None)  # canal removido some da lista
            except Exception:
                pass
            desejados = {chave_canal(c): c for c in self.cfg["canais"]
                         if self.ligado() and c.get("ativo", True) and chave_canal(c)}
            for chave, t in list(self.rodando.items()):
                if chave not in desejados:
                    t.parar.set()
                    del self.rodando[chave]
            for chave, c in desejados.items():
                t = self.rodando.get(chave)
                if t and t.is_alive() and not t.parar.is_set():
                    t.ccfg.update(c)
                    continue
                t = Canal(c, self.cfg, self.editor)
                self.rodando[chave] = t
                t.start()
            # canais desligados também aparecem no site (com o botão Monitorar desligado)
            for c in self.cfg["canais"]:
                chave = chave_canal(c)
                if chave and chave not in desejados:
                    status_canal(chave, status="cortador parado" if not self.ligado() else "monitoramento desligado",
                                 titulo="", monitorando=False, ativo=c.get("ativo", True),
                                 plataforma="youtube" if c.get("youtube") else "twitch",
                                 nome_bonito=c.get("nome") or chave)


def editar_corte(cfg, editor, jpath, faixa, titulo, extra=None):
    """Coloca card (faixa) + legenda das falas num rascunho e salva em prontos/ (usado por mim e pela IA)."""
    meta = json.loads(jpath.read_text(encoding="utf-8"))
    dados = jpath.parent
    faixa = re.sub(r"[^\w\s,.!?'\-À-ÿ]", "", faixa or "").strip().upper()   # sem emoji na faixa
    tag_nome = re.sub(r"[^a-z0-9]", "", meta.get("nome_bonito", meta["canal"]).lower())
    tags = cfg.get("hashtags", ["#gta6", "#gtavi", "#cortes", "#shorts"])
    titulo = re.sub(r'[\\/:*?"<>|]', "", f"{titulo or faixa} #{tag_nome} " + " ".join(tags)).strip()
    prontos = dados.parent / "prontos"
    prontos.mkdir(exist_ok=True)
    destino = nome_livre(prontos, titulo)
    editor.renderizar(meta, dados, destino, faixa=faixa or None)
    # tira o rascunho da pasta rascunhos/ para não confundir com os que faltam editar
    rasc = BASE / meta["rascunho"] if meta.get("rascunho") else None
    if rasc and rasc.exists():
        editados = rasc.parent / "ja_editados"
        editados.mkdir(exist_ok=True)
        rasc.replace(editados / rasc.name)
        meta["rascunho"] = str((editados / rasc.name).relative_to(BASE))
    meta.update({"status": "pronto", "faixa": faixa, "legenda_post": titulo,
                 "pronto": str(destino.relative_to(BASE)),
                 "editado_em": datetime.now().isoformat(timespec="seconds")})
    if extra:
        meta.update(extra)
    jpath.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    log(meta["canal"], f"PRONTO -> {destino.relative_to(BASE)}")
    contar_corte(meta["canal"], "pronto", titulo)
    return destino


def cortar_manual(cfg, editor, canal_txt, horario, antes, depois):
    """Corta um momento pelo horário do relógio, usando a gravação guardada (últimos 60 min)."""
    partes = [int(x) for x in horario.split(":")]
    h, m, s = (partes + [0, 0])[:3]
    alvo = datetime.now().replace(hour=h, minute=m, second=s, microsecond=0).timestamp()

    busca = re.sub(r"[^a-z0-9]", "", canal_txt.lower())
    raiz = BASE / cfg["pasta_gravacao"]
    canais = [p for p in raiz.iterdir() if p.is_dir() and busca in re.sub(r"[^a-z0-9]", "", p.name.lower())]
    if not canais:
        sys.exit(f"Nenhuma gravação de '{canal_txt}' em {raiz}")

    for pasta_canal in canais:
        for sessao in sorted(pasta_canal.iterdir(), reverse=True):
            mapa_arq, lista_arq = sessao / "mapa.csv", sessao / "segmentos.csv"
            if not (mapa_arq.exists() and lista_arq.exists()):
                continue
            mapa = [tuple(map(float, l.split(","))) for l in mapa_arq.read_text().split() if "," in l]
            if not mapa or not (mapa[0][0] - mapa[0][1] <= alvo <= mapa[-1][0]):
                continue
            # pega o ponto de referência mais próximo do horário pedido
            rel, pos_ref = min(mapa, key=lambda x: abs(x[0] - alvo))
            pos = pos_ref - (rel - alvo)
            ini, fim = max(0.0, pos - antes), pos + depois
            with open(lista_arq, newline="") as f:
                segs = [(n, float(i), float(e)) for n, i, e in csv.reader(f)]
            usados = [(n, i, e) for n, i, e in segs if e > ini and i < fim and (sessao / n).exists()]
            if not usados:
                sys.exit(f"A gravação desse horário já foi apagada (só guardo os últimos "
                         f"{cfg['guardar_gravacao_minutos']} min).")
            fim = min(fim, usados[-1][2])
            ccfg = next((c for c in cfg["canais"]
                         if busca in re.sub(r"[^a-z0-9]", "", (c.get("twitch") or c.get("youtube", "")).lower())), {})
            nome = pasta_canal.name
            log(nome, f"corte manual {horario}: {ini:.0f}s a {fim:.0f}s da gravação {sessao.name}")
            editor.processar(nome, [sessao / n for n, _, _ in usados], ini - usados[0][1], fim - ini,
                             ccfg.get("layout", "auto"), ccfg.get("facecam"),
                             {"canal": nome, "motivos": [f"manual {horario}"],
                              "horario": datetime.fromtimestamp(alvo).isoformat()},
                             ccfg.get("nome") or nome.removeprefix("yt_"))
            return
    sys.exit(f"Não achei gravação de '{canal_txt}' no horário {horario}.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(BASE / "config.json"))
    ap.add_argument("--teste", nargs=2, metavar=("VIDEO", "SEGUNDO"),
                    help="testa o editor cortando um vídeo local no segundo indicado")
    ap.add_argument("--editar", metavar="JSON", help="coloca faixa e título num rascunho (arquivo _dados/*.json)")
    ap.add_argument("--faixa", help="texto da faixa vermelha")
    ap.add_argument("--titulo", help="legenda do post (vira o nome do arquivo); hashtags são adicionadas")
    ap.add_argument("--pendentes", action="store_true", help="lista os rascunhos que ainda não têm faixa")
    ap.add_argument("--sem-janela", action="store_true", help="não abre a janela do app")
    ap.add_argument("--cortar", nargs=2, metavar=("CANAL", "HORARIO"),
                    help='corte manual: --cortar alanzoka 10:32  (ou 10:32:15)')
    ap.add_argument("--antes", type=float, default=30, help="segundos antes do horário (corte manual)")
    ap.add_argument("--depois", type=float, default=30, help="segundos depois do horário (corte manual)")
    a = ap.parse_args()
    cfg = carregar_config(a.config)

    if not shutil.which("ffmpeg"):
        sys.exit("ffmpeg não encontrado no PATH")

    editor = Editor(cfg)
    log("sistema", f"encoder de vídeo: {editor.encoder}")

    if a.cortar:
        cortar_manual(cfg, editor, a.cortar[0], a.cortar[1], a.antes, a.depois)
        return

    if a.pendentes:
        for j in sorted((BASE / cfg["pasta_saida"]).glob("**/_dados/*.json")):
            m = json.loads(j.read_text(encoding="utf-8"))
            if m.get("status") == "rascunho":
                print(j.relative_to(BASE))
        return

    if a.editar:
        editar_corte(cfg, editor, Path(a.editar).resolve(), a.faixa, a.titulo)
        return

    if a.teste:
        video, seg = Path(a.teste[0]).resolve(), float(a.teste[1])
        ini = max(0.0, seg - cfg["segundos_antes"])
        c = cfg["canais"][0] if cfg["canais"] else {}
        editor.processar("teste", [video], ini, cfg["segundos_antes"] + cfg["segundos_depois"],
                         c.get("layout", "auto"), c.get("facecam"))
        return

    # janela do app + trava: a porta do painel só abre uma vez (dois cortadores = cortes duplicados)
    import painel
    import site_sync
    agendador = site_sync.Agendador(cfg, log)
    try:
        painel.iniciar(cfg, a.config, agendador)
    except OSError:
        log("sistema", "O CORTADOR JÁ ESTÁ RODANDO. Abrindo a janela dele.")
        painel.abrir_janela()
        return
    agendador.start()
    if not a.sem_janela:
        painel.abrir_janela()
    editor.start()
    ger = Gerenciador(cfg, editor)
    painel.GERENCIADOR = ger
    ger.aplicar()
    log("sistema", f"monitorando {ger.quantos()} canais. Ctrl+C para sair.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        log("sistema", "saindo...")


if __name__ == "__main__":
    main()
